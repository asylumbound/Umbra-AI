# Scriptor Umbra AI - Intelligent Ghostwriting Assistant

A sophisticated GPT-powered chat portal designed specifically for ghostwriting assistance, featuring article creation, book writing, copywriting, and comprehensive long-form content development. Built with elegant design aesthetics inspired by efrtlss.ai and powered by OpenAI's advanced Assistant API with persistent conversation threads.

## 🌟 Features

### Core Functionality
- **OpenAI Assistant API Integration**: Advanced conversational AI with persistent memory and context
- **Thread Management**: Maintain conversation history across sessions for better context
- **Elegant UI Design**: Clean, minimalist interface matching efrtlss.ai aesthetic
- **Responsive Design**: Optimized for both desktop and mobile devices
- **Real-time Chat**: Instant messaging with typing indicators and smooth animations
- **Error Handling**: Comprehensive error management with user-friendly messages
- **Rate Limiting**: Built-in protection against API abuse
- **Security Features**: CORS protection, helmet security headers, and input validation

### Ghostwriting Specialization
- **Article Writing**: Professional article creation and editing assistance
- **Book Development**: Long-form manuscript development and chapter structuring
- **Copywriting**: Marketing copy, sales pages, and promotional content
- **Content Strategy**: Editorial planning and content optimization
- **Research Integration**: Fact-checking and source verification assistance
- **Style Adaptation**: Tone and voice customization for different audiences

### Technical Features
- **Modular Architecture**: Easy API provider switching (OpenAI, Anthropic, Mistral)
- **Environment Configuration**: Secure API key management
- **Production Ready**: Optimized for deployment on major platforms
- **Thread Persistence**: Conversation continuity across sessions
- **Auto-cleanup**: Automatic removal of old conversation threads

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm/pnpm
- OpenAI API key with Assistant API access
- OpenAI Assistant ID (configured in your OpenAI dashboard)

### Installation

1. **Clone and Setup Backend**
```bash
cd scriptor-umbra-backend
npm install
cp .env.example .env
```

2. **Configure Environment Variables**
Edit `.env` file:
```env
# OpenAI Configuration (Required)
OPENAI_API_KEY=your_openai_api_key_here
ASSISTANT_ID=your_assistant_id_here

# Server Configuration
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

# Security Settings
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

3. **Setup Frontend**
```bash
cd scriptor-umbra-frontend
pnpm install
```

4. **Start Development Servers**
```bash
# Terminal 1 - Backend
cd scriptor-umbra-backend
npm run dev

# Terminal 2 - Frontend  
cd scriptor-umbra-frontend
pnpm run dev
```

5. **Access Application**
- Frontend: http://localhost:5173
- Backend API: http://localhost:3001
- Health Check: http://localhost:3001/health

## 🔧 Configuration

### OpenAI Assistant Setup

1. **Create Assistant in OpenAI Dashboard**
   - Go to https://platform.openai.com/assistants
   - Create a new assistant with ghostwriting instructions
   - Copy the Assistant ID (starts with `asst_`)

2. **Configure Assistant Instructions**
```text
You are Scriptor Umbra AI, a professional ghostwriting assistant specializing in:
- Article writing and editing
- Book development and manuscript creation
- Copywriting and marketing content
- Content strategy and optimization
- Research and fact-checking
- Style adaptation and voice matching

Provide detailed, professional writing assistance with clear structure, engaging content, and proper formatting. Always maintain the user's intended tone and style while ensuring clarity and readability.
```

### API Provider Configuration

The system supports multiple AI providers through modular configuration:

**OpenAI Assistant API** (Recommended)
```env
OPENAI_API_KEY=sk-proj-...
ASSISTANT_ID=asst_...
```

**Alternative Providers** (Future Support)
```env
# Anthropic Claude
ANTHROPIC_API_KEY=sk-ant-...

# Mistral AI  
MISTRAL_API_KEY=...
```

## 📡 API Documentation

### Chat Endpoints

#### POST `/api/chat/completion`
Send message to Assistant API with thread management.

**Request:**
```json
{
  "message": "Help me write an introduction for my article",
  "threadId": "thread_abc123" // Optional, creates new if not provided
}
```

**Response:**
```json
{
  "success": true,
  "response": "Here's a compelling introduction for your article...",
  "threadId": "thread_abc123",
  "timestamp": "2025-06-22T21:00:00.000Z",
  "model": "assistant-api"
}
```

#### POST `/api/chat/thread/new`
Create a new conversation thread.

**Response:**
```json
{
  "success": true,
  "threadId": "thread_abc123",
  "timestamp": "2025-06-22T21:00:00.000Z"
}
```

#### GET `/api/chat/thread/:threadId/messages`
Retrieve conversation history for a thread.

**Response:**
```json
{
  "success": true,
  "messages": [
    {
      "id": "msg_123",
      "role": "user",
      "content": "Help me write an article",
      "timestamp": "2025-06-22T21:00:00.000Z"
    },
    {
      "id": "msg_124", 
      "role": "assistant",
      "content": "I would be happy to help you write an article...",
      "timestamp": "2025-06-22T21:00:05.000Z"
    }
  ],
  "threadId": "thread_abc123"
}
```

#### GET `/api/chat/health`
Check chat service status and configuration.

**Response:**
```json
{
  "status": "OK",
  "service": "Chat API (Assistant)",
  "openai_configured": true,
  "assistant_configured": true,
  "active_threads": 5,
  "timestamp": "2025-06-22T21:00:00.000Z"
}
```

## 🎨 Frontend Features

### Thread Management
- **Sidebar Navigation**: Browse and switch between conversation threads
- **Thread Creation**: Start new conversations with one click
- **Thread Persistence**: Conversations saved automatically
- **Thread Cleanup**: Old threads removed automatically after 24 hours

### Chat Interface
- **Real-time Messaging**: Instant message delivery and responses
- **Typing Indicators**: Visual feedback during AI processing
- **Message History**: Full conversation history with timestamps
- **Copy/Export**: Easy content copying and export options
- **Responsive Design**: Optimized for all screen sizes

## 🚀 Deployment

### Vercel Deployment (Recommended)

1. **Deploy Frontend**
```bash
cd scriptor-umbra-frontend
pnpm run build
npx vercel --prod
```

2. **Deploy Backend**
```bash
cd scriptor-umbra-backend
npx vercel --prod
```

3. **Configure Environment Variables**
In Vercel dashboard, add:
- `OPENAI_API_KEY`
- `ASSISTANT_ID`
- `FRONTEND_URL` (your frontend domain)

### Railway/Render Deployment

1. **Connect Repository**
2. **Configure Environment Variables**
3. **Deploy with Auto-scaling**

## 🔒 Security

### API Security
- **Rate Limiting**: 100 requests per 15 minutes per IP
- **CORS Protection**: Configured for specific frontend domains
- **Helmet Security**: Security headers and XSS protection
- **Input Validation**: Sanitized user inputs and API requests
- **Environment Variables**: Secure API key storage

### Data Privacy
- **No Data Storage**: Messages not permanently stored
- **Thread Cleanup**: Automatic removal of old conversations
- **API Key Security**: Keys never exposed to frontend
- **HTTPS Enforcement**: Secure communication in production

## 🛠️ Development

### Project Structure
```
scriptor-umbra-ai/
├── scriptor-umbra-frontend/     # React frontend
│   ├── src/
│   │   ├── components/          # React components
│   │   ├── hooks/              # Custom React hooks
│   │   ├── utils/              # Utility functions
│   │   └── styles/             # CSS and styling
│   ├── public/                 # Static assets
│   └── package.json
├── scriptor-umbra-backend/      # Node.js backend
│   ├── routes/                 # API route handlers
│   ├── middleware/             # Express middleware
│   ├── utils/                  # Helper functions
│   ├── server.js              # Main server file
│   └── package.json
└── README.md
```

## 🆘 Support

### Common Issues

**API Key Errors**
- Verify OpenAI API key is valid and has Assistant API access
- Check Assistant ID is correctly configured
- Ensure sufficient API credits

**Connection Issues**
- Verify backend is running on correct port
- Check CORS configuration for frontend domain
- Confirm firewall settings allow connections

**Thread Management**
- Threads automatically expire after 24 hours
- Create new thread if conversation seems lost
- Check browser console for JavaScript errors

---

**Built with ❤️ by Manus AI**

*Empowering writers with intelligent assistance for exceptional content creation.*

