# 🛡️ Render Deployment Package (Most Reliable)

## Professional-Grade Hosting

### **Why Render?**
- ✅ **750 free hours/month** (enough for small apps)
- ✅ **Automatic SSL** certificates
- ✅ **Zero downtime** deployments
- ✅ **Built-in monitoring** and health checks
- ✅ **Custom domains** included
- ✅ **PostgreSQL database** available

### **Step 1: Prepare for Render**

Your backend is already Render-ready! Create this file in your backend:

#### **render.yaml** (Optional - for advanced config)
```yaml
services:
  - type: web
    name: scriptor-umbra-api
    env: node
    plan: free
    buildCommand: npm install
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 10000
```

### **Step 2: Deploy to Render**

#### **Method 1: GitHub Integration (Recommended)**
1. Upload your backend to GitHub
2. Go to https://render.com
3. Sign up and verify email
4. Click **"New +"** → **"Web Service"**
5. Connect GitHub and select your repository
6. Configure:
   - **Name**: `scriptor-umbra-api`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: `Free`

#### **Method 2: Direct Upload**
1. Go to https://render.com
2. Click **"New +"** → **"Web Service"**
3. Select **"Build and deploy from a Git repository"**
4. Upload your backend folder as a ZIP
5. Follow the same configuration as above

### **Step 3: Environment Variables**

In Render dashboard, add these environment variables:

```
NODE_ENV=production
PORT=10000
SUPABASE_URL=https://lqyopzfoyllmgfbnjczt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
FRONTEND_URL=https://scriptorumbra.ai
```

### **Step 4: Get Your Backend URL**

Render provides a URL like:
```
https://scriptor-umbra-api.onrender.com
```

### **Step 5: Update Frontend**

Change the API URL in your frontend:

#### **File: `/src/App.jsx`**
```javascript
// Change from:
const API_BASE_URL = 'http://localhost:3001/api'

// To:
const API_BASE_URL = 'https://scriptor-umbra-api.onrender.com/api'
```

## 🔧 **Render-Specific Configuration**

### **Update server.js for Render**
Ensure your server listens on the correct port:

```javascript
const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Scriptor Umbra AI Backend running on port ${PORT}`);
});
```

### **Health Check Endpoint**
Render automatically monitors your `/health` endpoint:

```javascript
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Scriptor Umbra AI Backend is running',
    timestamp: new Date().toISOString()
  });
});
```

## 🎯 **Deployment Checklist**

- [ ] Create Render account
- [ ] Deploy backend via GitHub or upload
- [ ] Configure environment variables
- [ ] Wait for deployment to complete (5-10 minutes)
- [ ] Test health endpoint
- [ ] Update frontend API URL
- [ ] Rebuild and upload frontend
- [ ] Test complete functionality

## 🚨 **Important Render Notes**

### **Free Tier Limitations**
- **Sleep after 15 minutes** of inactivity
- **750 hours/month** total runtime
- **First request after sleep** takes 30-60 seconds

### **Preventing Sleep (Optional)**
Add a cron job to ping your service:
```javascript
// Add to your server.js
setInterval(() => {
  if (process.env.NODE_ENV === 'production') {
    fetch(`${process.env.RENDER_EXTERNAL_URL}/health`)
      .catch(err => console.log('Keep-alive ping failed:', err));
  }
}, 14 * 60 * 1000); // Ping every 14 minutes
```

### **Custom Domain Setup**
1. In Render dashboard → Settings → Custom Domains
2. Add `api.scriptorumbra.ai`
3. Update your DNS:
   ```
   CNAME api.scriptorumbra.ai → scriptor-umbra-api.onrender.com
   ```

## 🧪 **Testing Your Deployment**

### **Health Check**
```bash
curl https://scriptor-umbra-api.onrender.com/health
```

### **API Endpoints**
```bash
# Test authentication
curl -X POST https://scriptor-umbra-api.onrender.com/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"testpass","fullName":"Test User"}'

# Test chat
curl -X POST https://scriptor-umbra-api.onrender.com/api/chat/thread/new \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your_jwt_token"
```

## 🎉 **Advantages of Render**

1. **Reliability**: 99.9% uptime SLA
2. **Security**: Automatic SSL, DDoS protection
3. **Monitoring**: Built-in logs and metrics
4. **Scaling**: Easy upgrade to paid plans
5. **Database**: Free PostgreSQL available
6. **Git Integration**: Auto-deploy on push

Render is perfect for production applications that need reliability and professional features!

