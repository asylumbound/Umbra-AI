#!/bin/bash

# Backend Conversion Script for Cloud Deployment
# This script prepares your backend for different cloud platforms

echo "🚀 Backend Cloud Deployment Converter"
echo "======================================"

# Create directories for different platforms
mkdir -p cloud-backends/{railway,render,vercel}

echo "📦 Creating Railway package..."
# Railway - Direct copy (works as-is)
cp -r scriptor-umbra-backend/* cloud-backends/railway/
echo "✅ Railway package ready at: cloud-backends/railway/"

echo "📦 Creating Render package..."
# Render - Add render.yaml and update package.json
cp -r scriptor-umbra-backend/* cloud-backends/render/

# Create render.yaml for Render
cat > cloud-backends/render/render.yaml << 'EOF'
services:
  - type: web
    name: scriptor-umbra-api
    env: node
    plan: free
    buildCommand: npm install
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 10000
EOF

# Update package.json for Render
cd cloud-backends/render
npm pkg set scripts.start="node server.js"
cd ../..
echo "✅ Render package ready at: cloud-backends/render/"

echo "📦 Creating Vercel serverless package..."
# Vercel - Convert to serverless functions
mkdir -p cloud-backends/vercel/{api,lib}

# Copy shared utilities
cp scriptor-umbra-backend/config/* cloud-backends/vercel/lib/ 2>/dev/null || true
cp scriptor-umbra-backend/middleware/* cloud-backends/vercel/lib/ 2>/dev/null || true

# Create package.json for Vercel
cat > cloud-backends/vercel/package.json << 'EOF'
{
  "name": "scriptor-umbra-vercel",
  "version": "1.0.0",
  "dependencies": {
    "@supabase/supabase-js": "^2.39.0",
    "openai": "^4.20.1",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "cors": "^2.8.5"
  }
}
EOF

# Create vercel.json
cat > cloud-backends/vercel/vercel.json << 'EOF'
{
  "version": 2,
  "functions": {
    "api/**/*.js": {
      "runtime": "nodejs18.x"
    }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "Access-Control-Allow-Origin", "value": "https://scriptorumbra.ai" },
        { "key": "Access-Control-Allow-Methods", "value": "GET, POST, PUT, DELETE, OPTIONS" },
        { "key": "Access-Control-Allow-Headers", "value": "Content-Type, Authorization" }
      ]
    }
  ]
}
EOF

# Create basic serverless functions
mkdir -p cloud-backends/vercel/api/{auth,chat/thread,conversations}

# Health check function
cat > cloud-backends/vercel/api/health.js << 'EOF'
export default function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  res.status(200).json({
    status: 'OK',
    message: 'Scriptor Umbra AI Backend is running',
    timestamp: new Date().toISOString()
  });
}
EOF

echo "✅ Vercel serverless package ready at: cloud-backends/vercel/"

echo ""
echo "🎯 Deployment Packages Created:"
echo "================================"
echo "📁 Railway:  cloud-backends/railway/  (Ready to upload)"
echo "📁 Render:   cloud-backends/render/   (Ready to upload)"  
echo "📁 Vercel:   cloud-backends/vercel/   (Needs function conversion)"
echo ""
echo "📖 Next Steps:"
echo "1. Choose your preferred platform (Railway recommended for speed)"
echo "2. Upload the corresponding package"
echo "3. Configure environment variables"
echo "4. Update frontend API URL"
echo ""
echo "🚀 Happy deploying!"

