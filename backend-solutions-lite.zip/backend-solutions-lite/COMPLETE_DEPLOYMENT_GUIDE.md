# 🚀 Complete Backend Deployment Guide

## No Root Access? No Problem!

Since you can't install Node.js on DreamHost shared hosting, here are three excellent cloud alternatives that will get your Scriptor Umbra AI backend running in minutes.



## 🎯 Platform Comparison

| Feature | Railway | Render | Vercel |
|---------|---------|--------|--------|
| **Setup Time** | 2 minutes | 5 minutes | 10 minutes |
| **Free Tier** | $5 credit/month | 750 hours/month | Generous limits |
| **Best For** | Quick deployment | Reliable hosting | Full-stack apps |
| **Difficulty** | ⭐ Easy | ⭐⭐ Medium | ⭐⭐⭐ Advanced |
| **Auto-scaling** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Custom Domain** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Database** | Add-on | Built-in PostgreSQL | External required |

## 🏆 Recommended Choice: Railway

**Why Railway?**
- Fastest deployment (2 minutes)
- Zero configuration required
- Auto-detects Node.js projects
- $5 monthly credit covers small apps
- Perfect for getting started quickly



## 🚂 Railway Deployment (Recommended)

### **Step 1: Prepare Your Backend**
Your backend is already configured! You have:
- ✅ Express server with all routes
- ✅ Supabase authentication integration
- ✅ OpenAI Assistant API setup
- ✅ CORS configuration for your domain
- ✅ Environment variable support

### **Step 2: Deploy to Railway**

#### **Option A: GitHub Upload (Recommended)**
1. **Create GitHub Repository**
   - Go to https://github.com
   - Create new repository: `scriptor-umbra-backend`
   - Upload your backend folder

2. **Deploy via Railway**
   - Go to https://railway.app
   - Sign up with GitHub or email
   - Click **"New Project"**
   - Select **"Deploy from GitHub repo"**
   - Choose your `scriptor-umbra-backend` repository
   - Railway auto-deploys! 🎉

#### **Option B: Direct Upload**
1. **Go to Railway**
   - Visit https://railway.app
   - Sign up and verify email

2. **Create Project**
   - Click **"New Project"**
   - Select **"Empty Project"**
   - Click **"GitHub Repo"** or **"Deploy from GitHub repo"**

3. **Upload Backend**
   - Zip your `scriptor-umbra-backend` folder
   - Upload to Railway
   - Railway detects Node.js and installs dependencies

### **Step 3: Configure Environment Variables**

In Railway dashboard, go to **Variables** tab and add:

```
NODE_ENV=production
PORT=3001
SUPABASE_URL=https://lqyopzfoyllmgfbnjczt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_from_supabase
OPENAI_API_KEY=your_openai_api_key
OPENAI_ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
FRONTEND_URL=https://scriptorumbra.ai
```

**🔑 Where to find keys:**
- **Supabase Service Role Key**: Supabase Dashboard → Settings → API → `service_role` key
- **OpenAI API Key**: Your existing key from OpenAI dashboard

### **Step 4: Get Your Backend URL**

After deployment, Railway provides a URL like:
```
https://scriptor-umbra-backend-production.up.railway.app
```

### **Step 5: Test Your Backend**

Visit your Railway URL + `/health`:
```
https://your-app.railway.app/health
```

Should return:
```json
{
  "status": "OK",
  "message": "Scriptor Umbra AI Backend is running"
}
```

### **Step 6: Update Frontend**

Edit your frontend's API configuration:

**File to change:** `/src/App.jsx`
```javascript
// Change this line:
const API_BASE_URL = 'http://localhost:3001/api'

// To your Railway URL:
const API_BASE_URL = 'https://your-app.railway.app/api'
```

### **Step 7: Rebuild and Deploy Frontend**

```bash
# In your frontend folder
npm run build

# Upload the new dist/ contents to DreamHost
```

### **Step 8: Test Complete System**

1. **Visit your site**: https://scriptorumbra.ai
2. **Test signup**: Create a new account
3. **Test login**: Sign in with your account
4. **Test chat**: Send a message to the AI
5. **Test navigation**: Switch between Chat and Dashboard

## ✅ Railway Deployment Checklist

- [ ] Create Railway account
- [ ] Upload backend to GitHub (optional but recommended)
- [ ] Deploy backend via Railway
- [ ] Add all environment variables
- [ ] Test backend health endpoint
- [ ] Update frontend API URL
- [ ] Rebuild and upload frontend
- [ ] Test complete authentication flow
- [ ] Test chat functionality
- [ ] Verify conversations are saved in Supabase


## 🛡️ Render Deployment (Most Reliable)

### **When to Choose Render**
- You want maximum reliability (99.9% uptime)
- You need built-in PostgreSQL database
- You prefer professional-grade hosting
- You want zero-downtime deployments

### **Step 1: Prepare for Render**

Your backend works with Render out of the box! Optionally create this file:

**render.yaml** (in your backend root):
```yaml
services:
  - type: web
    name: scriptor-umbra-api
    env: node
    plan: free
    buildCommand: npm install
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
```

### **Step 2: Deploy to Render**

#### **Method 1: GitHub Integration**
1. **Upload to GitHub**
   - Create repository: `scriptor-umbra-backend`
   - Upload your backend files

2. **Deploy via Render**
   - Go to https://render.com
   - Sign up and verify email
   - Click **"New +"** → **"Web Service"**
   - Connect GitHub and select repository

3. **Configure Service**
   - **Name**: `scriptor-umbra-api`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: `Free`

#### **Method 2: Direct Upload**
1. **Go to Render**
   - Visit https://render.com
   - Create account

2. **Create Web Service**
   - Click **"New +"** → **"Web Service"**
   - Select **"Build and deploy from a Git repository"**
   - Upload your backend as ZIP file

### **Step 3: Environment Variables**

In Render dashboard, add these variables:

```
NODE_ENV=production
PORT=10000
SUPABASE_URL=https://lqyopzfoyllmgfbnjczt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
OPENAI_API_KEY=your_openai_api_key
OPENAI_ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
FRONTEND_URL=https://scriptorumbra.ai
```

### **Step 4: Get Your Backend URL**

Render provides a URL like:
```
https://scriptor-umbra-api.onrender.com
```

### **Step 5: Update Frontend**

Change API URL in `/src/App.jsx`:
```javascript
const API_BASE_URL = 'https://scriptor-umbra-api.onrender.com/api'
```

### **Step 6: Handle Free Tier Sleep**

Render free tier sleeps after 15 minutes of inactivity. Add this to your `server.js`:

```javascript
// Keep-alive for Render free tier
if (process.env.NODE_ENV === 'production' && process.env.RENDER_EXTERNAL_URL) {
  setInterval(() => {
    fetch(`${process.env.RENDER_EXTERNAL_URL}/health`)
      .catch(err => console.log('Keep-alive ping failed:', err));
  }, 14 * 60 * 1000); // Ping every 14 minutes
}
```

## ✅ Render Deployment Checklist

- [ ] Create Render account
- [ ] Upload backend to GitHub (recommended)
- [ ] Create Web Service in Render
- [ ] Configure build and start commands
- [ ] Add all environment variables
- [ ] Wait for deployment (5-10 minutes)
- [ ] Test health endpoint
- [ ] Update frontend API URL
- [ ] Add keep-alive ping (optional)
- [ ] Test complete functionality


## 🔧 Troubleshooting Common Issues

### **Backend Not Starting**

**Problem**: Deployment fails or backend won't start
**Solutions**:
1. Check build logs in platform dashboard
2. Verify `package.json` has correct start script:
   ```json
   {
     "scripts": {
       "start": "node server.js"
     }
   }
   ```
3. Ensure all dependencies are in `package.json`
4. Check Node.js version compatibility

### **Environment Variables Not Working**

**Problem**: Backend can't connect to Supabase or OpenAI
**Solutions**:
1. Double-check all environment variable names (case-sensitive)
2. Verify Supabase Service Role Key (not anon key)
3. Test OpenAI API key in OpenAI dashboard
4. Restart deployment after adding variables

### **CORS Errors**

**Problem**: Frontend can't connect to backend
**Solutions**:
1. Verify CORS configuration in `server.js`:
   ```javascript
   app.use(cors({
     origin: ['https://scriptorumbra.ai', 'https://www.scriptorumbra.ai'],
     credentials: true
   }));
   ```
2. Update frontend API URL to match backend URL exactly
3. Check browser console for specific CORS errors

### **Authentication Not Working**

**Problem**: Login/signup fails
**Solutions**:
1. Verify Supabase URL configuration in Supabase dashboard
2. Check redirect URLs in Supabase Authentication settings
3. Ensure JWT secret is properly configured
4. Test Supabase connection directly

### **Chat Not Working**

**Problem**: AI responses fail
**Solutions**:
1. Verify OpenAI API key has sufficient credits
2. Check Assistant ID is correct: `asst_SIM27MLhW3jL4xRG6SyNzFzc`
3. Test OpenAI API connection in backend logs
4. Verify thread creation is working

### **Free Tier Limitations**

**Railway Free Tier**:
- $5 credit per month
- Automatic scaling
- No sleep issues

**Render Free Tier**:
- 750 hours per month
- Sleeps after 15 minutes inactivity
- 30-60 second cold start

**Vercel Free Tier**:
- 100GB-seconds per month
- 10-second function timeout
- No persistent connections

## 🧪 Testing Commands

### **Test Backend Health**
```bash
curl https://your-backend-url/health
```

### **Test Authentication**
```bash
curl -X POST https://your-backend-url/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"testpass","fullName":"Test User"}'
```

### **Test Chat Endpoint**
```bash
curl -X POST https://your-backend-url/api/chat/thread/new \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your_jwt_token"
```

## 📞 Getting Help

### **Platform Support**
- **Railway**: https://railway.app/help
- **Render**: https://render.com/docs
- **Vercel**: https://vercel.com/docs

### **Common Error Messages**

**"Module not found"**
- Solution: Add missing dependency to `package.json`

**"Port already in use"**
- Solution: Use `process.env.PORT` in server.js

**"Unauthorized"**
- Solution: Check Supabase service role key

**"OpenAI API error"**
- Solution: Verify API key and check credits

## 🎯 Success Indicators

✅ **Backend Health Check**: Returns 200 status
✅ **User Registration**: Creates account in Supabase
✅ **User Login**: Returns JWT token
✅ **Chat Functionality**: AI responds to messages
✅ **Conversation Persistence**: Messages saved to database
✅ **Navigation**: Chat ↔ Dashboard works
✅ **Sign Out**: Clears session properly


## 🎉 Final Recommendations

### **For Quick Setup (2 minutes)**
**Choose Railway** if you want:
- Fastest deployment
- Zero configuration
- Automatic scaling
- $5 monthly credit

### **For Production Reliability**
**Choose Render** if you want:
- 99.9% uptime SLA
- Built-in monitoring
- Professional features
- PostgreSQL database

### **For Full-Stack Development**
**Choose Vercel** if you want:
- Serverless architecture
- Global CDN
- Git integration
- Advanced scaling

## 🚀 Quick Start Summary

1. **Choose Platform**: Railway (recommended for speed)
2. **Deploy Backend**: Upload to chosen platform
3. **Add Environment Variables**: Supabase + OpenAI keys
4. **Get Backend URL**: Copy from platform dashboard
5. **Update Frontend**: Change API_BASE_URL
6. **Test Everything**: Authentication + Chat + Navigation

## 📦 What You Get

After deployment, your Scriptor Umbra AI will have:

✅ **Complete User Authentication**
- User registration with email verification
- Secure login/logout with JWT tokens
- User profiles with subscription tiers

✅ **Advanced Chat System**
- OpenAI Assistant integration
- Conversation history and management
- Real-time message persistence

✅ **Professional Dashboard**
- User statistics and usage tracking
- Conversation management interface
- Subscription tier display

✅ **Production-Ready Features**
- Mobile-responsive design
- Security headers and CORS protection
- Error handling and logging
- Automatic scaling and monitoring

## 🎯 Your Next Steps

1. **Pick a platform** (Railway for speed, Render for reliability)
2. **Follow the step-by-step guide** for your chosen platform
3. **Deploy in under 10 minutes**
4. **Enjoy your fully functional AI writing assistant!**

No more server administration headaches - just pure AI-powered writing assistance for your users!

