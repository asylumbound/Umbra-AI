# 🚀 Node.js Installation & Backend Deployment - DreamHost VPS

## 🔍 **Issue Identified**
Your VPS doesn't have Node.js/npm installed. Let's fix this and get your backend running.

## 📋 **Step-by-Step Installation**

### **Step 1: Install Node.js via Node Version Manager (NVM)**

Run these commands on your VPS:

```bash
# Download and install NVM
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# Reload your shell configuration
source ~/.bashrc

# Install the latest LTS version of Node.js
nvm install --lts

# Use the LTS version
nvm use --lts

# Verify installation
node --version
npm --version
```

### **Step 2: Alternative - Direct Node.js Installation**

If NVM doesn't work, try direct installation:

```bash
# Update package manager
sudo apt update

# Install Node.js and npm
sudo apt install -y nodejs npm

# Verify installation
node --version
npm --version
```

### **Step 3: Install Your Backend Dependencies**

Once Node.js is installed:

```bash
# Navigate to your backend directory
cd /path/to/your/backend

# Install production dependencies
npm install --production

# Or install all dependencies
npm install
```

## 🔧 **Complete Backend Setup Commands**

Here's the complete sequence to run on your VPS:

```bash
# 1. Install Node.js (choose one method)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install --lts
nvm use --lts

# 2. Navigate to your backend directory
cd /home/scriptorumbra/scriptorumbra.ai

# 3. Install dependencies
npm install --production

# 4. Set up environment variables
cp .env.production .env
nano .env  # Edit with your actual values

# 5. Test the server
node server.js

# 6. Install PM2 for production (keeps server running)
npm install -g pm2

# 7. Start server with PM2
pm2 start server.js --name "scriptor-umbra-api"

# 8. Save PM2 configuration
pm2 save
pm2 startup
```

## ⚙️ **Environment Configuration**

Create/edit your `.env` file:

```bash
nano .env
```

Add these variables:
```env
# Server Configuration
PORT=3001
NODE_ENV=production

# Frontend URL
FRONTEND_URL=https://scriptorumbra.ai

# OpenAI Configuration
OPENAI_API_KEY=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
OPENAI_ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc

# Supabase Configuration
SUPABASE_URL=https://lqyopzfoyllmgfbnjczt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-here
```

## 🔥 **Firewall Configuration**

Open port 3001 for your API:

```bash
# Check if ufw is installed
sudo ufw status

# If ufw is available, open port 3001
sudo ufw allow 3001

# Or use iptables
sudo iptables -A INPUT -p tcp --dport 3001 -j ACCEPT
```

## 🧪 **Testing Your Backend**

### **Test 1: Local Server Test**
```bash
# Start server manually
node server.js

# Should see: "Server running on port 3001"
```

### **Test 2: Health Check**
```bash
# In another terminal or browser
curl http://localhost:3001/health

# Should return: {"status":"OK","message":"Scriptor Umbra AI Backend is running"}
```

### **Test 3: External Access**
```bash
# Test from outside the server
curl http://vps64698.dreamhostps.com:3001/health
```

## 🚀 **Production Deployment with PM2**

### **Install and Configure PM2**
```bash
# Install PM2 globally
npm install -g pm2

# Start your application
pm2 start server.js --name "scriptor-umbra-api"

# View running processes
pm2 list

# View logs
pm2 logs scriptor-umbra-api

# Restart application
pm2 restart scriptor-umbra-api

# Stop application
pm2 stop scriptor-umbra-api
```

### **Auto-start on Server Reboot**
```bash
# Generate startup script
pm2 startup

# Save current PM2 configuration
pm2 save
```

## 🔧 **Troubleshooting**

### **Issue: "Permission denied"**
```bash
# Fix permissions
sudo chown -R $USER:$USER /home/scriptorumbra/scriptorumbra.ai
chmod +x server.js
```

### **Issue: "Port already in use"**
```bash
# Find what's using port 3001
sudo lsof -i :3001

# Kill the process (replace PID with actual process ID)
sudo kill -9 PID
```

### **Issue: "Module not found"**
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

## 📊 **Monitoring Your Backend**

### **Check Server Status**
```bash
# PM2 status
pm2 status

# Server logs
pm2 logs scriptor-umbra-api --lines 50

# System resources
htop
```

### **Health Monitoring**
```bash
# Create a simple health check script
echo '#!/bin/bash
curl -f http://localhost:3001/health || echo "Backend is down!"' > health_check.sh
chmod +x health_check.sh

# Run health check
./health_check.sh
```

## 🌐 **Connecting Frontend to Backend**

Update your frontend to use your VPS backend:

1. **Option 1: Direct VPS Connection**
   - Backend URL: `http://vps64698.dreamhostps.com:3001`
   - Update frontend API calls to use this URL

2. **Option 2: Reverse Proxy (Recommended)**
   - Set up nginx to proxy requests
   - Use subdomain like `api.scriptorumbra.ai`

## ✅ **Success Checklist**

- [ ] Node.js and npm installed
- [ ] Dependencies installed successfully
- [ ] Environment variables configured
- [ ] Server starts without errors
- [ ] Health endpoint responds
- [ ] PM2 configured for production
- [ ] Firewall allows port 3001
- [ ] Auto-start configured

Your backend should now be running successfully on your DreamHost VPS!

