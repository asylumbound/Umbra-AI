const { verifyToken, getUserProfile, createUserProfile } = require('../config/supabase');

// Authentication middleware
const authenticateUser = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'Authentication required',
        message: 'Please provide a valid authentication token'
      });
    }

    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    
    // Verify the token with Supabase
    const user = await verifyToken(token);
    
    if (!user) {
      return res.status(401).json({
        error: 'Invalid token',
        message: 'The provided authentication token is invalid or expired'
      });
    }

    // Get or create user profile
    let profile = await getUserProfile(user.id);
    
    if (!profile) {
      // Create profile if it doesn't exist
      profile = await createUserProfile(user);
      
      if (!profile) {
        return res.status(500).json({
          error: 'Profile creation failed',
          message: 'Failed to create user profile'
        });
      }
    }

    // Attach user and profile to request
    req.user = user;
    req.profile = profile;
    
    next();
  } catch (error) {
    console.error('Authentication middleware error:', error);
    res.status(500).json({
      error: 'Authentication error',
      message: 'An error occurred during authentication'
    });
  }
};

// Optional authentication middleware (doesn't fail if no token)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const user = await verifyToken(token);
      
      if (user) {
        const profile = await getUserProfile(user.id);
        req.user = user;
        req.profile = profile;
      }
    }
    
    next();
  } catch (error) {
    console.error('Optional auth middleware error:', error);
    // Continue without authentication
    next();
  }
};

// Admin authentication middleware
const authenticateAdmin = async (req, res, next) => {
  try {
    await authenticateUser(req, res, () => {
      // Check if user has admin role
      if (req.profile?.subscription_tier !== 'enterprise' && req.user?.email !== process.env.ADMIN_EMAIL) {
        return res.status(403).json({
          error: 'Admin access required',
          message: 'This endpoint requires administrator privileges'
        });
      }
      next();
    });
  } catch (error) {
    console.error('Admin authentication error:', error);
    res.status(500).json({
      error: 'Admin authentication error',
      message: 'An error occurred during admin authentication'
    });
  }
};

// Rate limiting middleware based on user tier
const rateLimitByTier = (req, res, next) => {
  if (!req.profile) {
    return next();
  }

  const tier = req.profile.subscription_tier;
  const usage = req.profile.api_usage_count;
  const limit = req.profile.api_usage_limit;

  // Check if user has exceeded their quota
  if (usage >= limit) {
    return res.status(429).json({
      error: 'API quota exceeded',
      message: `You have exceeded your ${tier} tier limit of ${limit} requests. Please upgrade your subscription or wait for the quota to reset.`,
      quota: {
        used: usage,
        limit: limit,
        tier: tier
      }
    });
  }

  // Add quota info to response headers
  res.set({
    'X-RateLimit-Limit': limit.toString(),
    'X-RateLimit-Remaining': (limit - usage).toString(),
    'X-RateLimit-Reset': new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours from now
  });

  next();
};

module.exports = {
  authenticateUser,
  optionalAuth,
  authenticateAdmin,
  rateLimitByTier
};

