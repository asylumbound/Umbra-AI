# 🚀 DreamHost VPS Quick Commands

## Connect to Your Server
```bash
ssh username@vps64698.dreamhostps.com
```

## One-Time Setup
```bash
# 1. Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. Create backend directory
mkdir -p ~/scriptor-umbra-backend
cd ~/scriptor-umbra-backend
```

## Upload Files (from your local machine)
```bash
scp -r BACKEND_STANDALONE/* username@vps64698.dreamhostps.com:/home/username/scriptor-umbra-backend/
```

## Deploy Backend
```bash
# 3. Install dependencies
cd ~/scriptor-umbra-backend
npm install

# 4. Start the backend
chmod +x deploy.sh
./deploy.sh

# Or manually:
npm start
```

## Configure Firewall
```bash
sudo ufw allow 3001
sudo ufw enable
```

## Test Deployment
```bash
# Local test
curl http://localhost:3001/health

# External test
curl http://vps64698.dreamhostps.com:3001/health
```

## Production Setup (Optional)
```bash
# Install PM2
sudo npm install -g pm2

# Start with PM2
pm2 start server.js --name "scriptor-umbra"
pm2 save
pm2 startup
```

## Your Backend URLs
- Health: `http://vps64698.dreamhostps.com:3001/health`
- API: `http://vps64698.dreamhostps.com:3001/api/chat/completion`

## Troubleshooting
```bash
# Check if running
ps aux | grep node

# Check logs (if using PM2)
pm2 logs scriptor-umbra

# Restart service
pm2 restart scriptor-umbra
```

---
**Your backend is pre-configured with your OpenAI credentials and ready to use!**

