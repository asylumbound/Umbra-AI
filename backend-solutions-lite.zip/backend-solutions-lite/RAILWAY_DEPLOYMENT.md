# 🚀 Railway Deployment Package

## Quick 2-Minute Deployment

### **Step 1: Prepare Your Backend**
Your backend is already configured and ready! Here's what you have:

```
📁 scriptor-umbra-backend/
├── 📄 server.js              # Express server
├── 📄 package.json           # Dependencies
├── 📁 routes/                # API endpoints
├── 📁 config/                # Supabase config
├── 📁 middleware/            # Authentication
└── ⚙️ .env                   # Environment variables
```

### **Step 2: Deploy to Railway**

#### **Option A: Web Upload (Easiest)**
1. Go to https://railway.app
2. Sign up with GitHub or email
3. Click **"New Project"**
4. Select **"Deploy from GitHub repo"** or **"Empty Project"**
5. If empty project, click **"Deploy from GitHub repo"** later
6. Upload your `scriptor-umbra-backend` folder
7. Railway auto-detects Node.js and deploys!

#### **Option B: GitHub Integration (Recommended)**
1. Upload your backend to GitHub (public or private repo)
2. Go to Railway → **"New Project"**
3. Select **"Deploy from GitHub repo"**
4. Choose your repository
5. Railway auto-deploys and gives you a URL!

### **Step 3: Get Your Backend URL**
After deployment, Railway provides a URL like:
```
https://scriptor-umbra-backend-production.up.railway.app
```

### **Step 4: Environment Variables**
In Railway dashboard, add these environment variables:
```
NODE_ENV=production
PORT=3001
SUPABASE_URL=https://lqyopzfoyllmgfbnjczt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_from_supabase_dashboard
OPENAI_API_KEY=your_openai_api_key
OPENAI_ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
FRONTEND_URL=https://scriptorumbra.ai
```

### **Step 5: Test Your Backend**
Visit your Railway URL + `/health`:
```
https://your-app.railway.app/health
```

Should return:
```json
{"status":"OK","message":"Scriptor Umbra AI Backend is running"}
```

## 🔧 **Frontend Update Required**

Update your frontend's API URL:

### **File to Edit: `/src/App.jsx`**
Change this line:
```javascript
const API_BASE_URL = 'http://localhost:3001/api'
```

To:
```javascript
const API_BASE_URL = 'https://your-app.railway.app/api'
```

### **Rebuild Frontend**
```bash
npm run build
```

Upload the new `dist/` contents to your DreamHost domain.

## 🎯 **Complete Setup Checklist**

- [ ] Deploy backend to Railway
- [ ] Add environment variables in Railway dashboard
- [ ] Get your Railway backend URL
- [ ] Update frontend API_BASE_URL
- [ ] Rebuild and upload frontend
- [ ] Test login/signup functionality
- [ ] Test chat functionality
- [ ] Verify conversations are saved

## 🚨 **Important Notes**

1. **Get Supabase Service Role Key**: 
   - Go to Supabase Dashboard → Settings → API
   - Copy the `service_role` key (not the `anon` key)

2. **Railway Free Tier**: 
   - $5 credit per month
   - Enough for small to medium apps
   - Automatic scaling

3. **Custom Domain (Optional)**:
   - Railway allows custom domains
   - You can use `api.scriptorumbra.ai` → Railway
   - Keep `scriptorumbra.ai` → DreamHost frontend

## 🧪 **Testing Commands**

```bash
# Test backend health
curl https://your-app.railway.app/health

# Test authentication endpoint
curl https://your-app.railway.app/api/auth/signup

# Test chat endpoint
curl https://your-app.railway.app/api/chat/thread/new
```

Railway deployment is the fastest way to get your backend running without any server administration!

