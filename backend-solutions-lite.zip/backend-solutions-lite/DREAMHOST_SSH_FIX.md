# 🎯 DreamHost Panel SSH Fix - Step by Step

## 📍 Current Status
- ✅ You're logged into DreamHost panel
- ❌ SSH connection refused to vps64698.dreamhostps.com
- 🎯 Goal: Enable SSH access and fix connection

## 🔧 Step-by-Step Fix Instructions

### Step 1: Check VPS Status
1. **Look for navigation menu** (usually on left side or top)
2. **Click on "VPS"** or **"Private Servers"**
3. **Find**: vps64698.dreamhostps.com in the list
4. **Check Status**: Should say "Running" not "Stopped"
   - If stopped: Click "Start" button
   - Wait 2-3 minutes for startup

### Step 2: Check SSH Users
1. **Navigate to**: "Users" section (in main menu)
2. **Look for**: User accounts associated with your VPS
3. **Check each user** for:
   - ✅ **Shell Access**: Should be "Enabled" or "Yes"
   - ✅ **Server**: Should include vps64698
   - ✅ **Type**: Should be "Shell User" not just "FTP"

### Step 3: Enable SSH Access (if disabled)
1. **Find your user** in the Users list
2. **Click "Edit"** next to the username
3. **Look for "Shell Access"** checkbox or dropdown
4. **Enable/Check** Shell Access
5. **Select Server**: vps64698.dreamhostps.com
6. **Set Password**: Create a strong password
7. **Click "Save Changes"**

### Step 4: Create New SSH User (if none exist)
1. **In Users section**: Click "Add New User"
2. **Username**: Choose a username (e.g., "admin" or "deploy")
3. **Server**: Select vps64698.dreamhostps.com
4. **User Type**: Select "Shell User"
5. **Password**: Set a strong password
6. **Click "Add User"**

### Step 5: Check Firewall/Security Settings
1. **Look for**: "Security" or "Firewall" in menu
2. **Check**: SSH (port 22) is allowed
3. **If blocked**: Add rule to allow SSH
4. **Save changes**

### Step 6: Verify VPS Configuration
1. **Go back to VPS section**
2. **Click on**: vps64698.dreamhostps.com
3. **Check**: 
   - Memory allocation
   - Disk space
   - Network settings
4. **Look for**: SSH configuration options

## 🧪 Test SSH Connection

After making changes, wait 2-3 minutes then test:

```bash
# Use the username you just created/enabled
ssh username@vps64698.dreamhostps.com

# Examples:
ssh admin@vps64698.dreamhostps.com
ssh deploy@vps64698.dreamhostps.com
ssh allenhenson@vps64698.dreamhostps.com
```

## 🔍 What to Look For

### Success Indicators:
- User shows "Shell Access: Enabled"
- VPS status is "Running"
- SSH connection works without "connection refused"

### Common Issues:
- **No Shell Users**: Need to create one
- **VPS Stopped**: Need to start it
- **Wrong Username**: Check Users section for correct name
- **Firewall Blocking**: Need to allow SSH in security settings

## 🆘 If Still Not Working

### Option 1: Use DreamHost Web Terminal
1. **In VPS section**: Look for "Console" or "Web Terminal"
2. **Click to open**: Browser-based terminal
3. **Use this instead**: For deployment commands

### Option 2: Contact DreamHost Support
1. **Look for**: "Support" or "Help" in panel
2. **Open ticket**: "SSH connection refused on VPS"
3. **Include**: vps64698.dreamhostps.com details

### Option 3: Deploy to Cloud Instead
Skip DreamHost SSH issues entirely:
1. **Go to**: https://railway.app
2. **Upload**: Your BACKEND_STANDALONE folder
3. **Get instant URL**: Working in 2 minutes

## ✅ Success Test

You'll know it's fixed when this works:
```bash
ssh username@vps64698.dreamhostps.com
Welcome to Ubuntu 20.04.x LTS
username@vps64698:~$
```

## 🚀 Next Steps After SSH Works

1. **Install Node.js**:
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

2. **Deploy Backend**:
```bash
mkdir -p ~/scriptor-umbra-backend
cd ~/scriptor-umbra-backend
# Upload files and run deployment
```

---

**The most common issue is that Shell Access isn't enabled for any users on the VPS. Check the Users section first!**

