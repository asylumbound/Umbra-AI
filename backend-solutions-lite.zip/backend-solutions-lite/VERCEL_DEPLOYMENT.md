# ⚡ Vercel Deployment Package (Full-Stack Solution)

## Serverless Backend + Frontend Hosting

### **Why Vercel?**
- ✅ **Generous free tier** for personal projects
- ✅ **Serverless functions** (no server management)
- ✅ **Global CDN** for fast worldwide access
- ✅ **Automatic scaling** based on demand
- ✅ **Git integration** with auto-deployment
- ✅ **Custom domains** with free SSL

### **Step 1: Convert Backend to Serverless**

Vercel uses serverless functions instead of a traditional server. We need to restructure your backend:

#### **Create `/api` folder structure:**
```
📁 vercel-backend/
├── 📁 api/
│   ├── 📄 health.js           # Health check endpoint
│   ├── 📁 auth/
│   │   ├── 📄 signup.js       # User registration
│   │   ├── 📄 login.js        # User login
│   │   └── 📄 logout.js       # User logout
│   ├── 📁 chat/
│   │   ├── 📄 completion.js   # Chat completion
│   │   └── 📁 thread/
│   │       └── 📄 new.js      # New thread creation
│   └── 📁 conversations/
│       ├── 📄 index.js        # List conversations
│       └── 📄 [id].js         # Get specific conversation
├── 📄 package.json            # Dependencies
├── 📄 vercel.json             # Vercel configuration
└── 📁 lib/                    # Shared utilities
    ├── 📄 supabase.js         # Supabase client
    └── 📄 middleware.js       # Auth middleware
```

### **Step 2: Vercel Configuration**

#### **vercel.json**
```json
{
  "version": 2,
  "functions": {
    "api/**/*.js": {
      "runtime": "nodejs18.x"
    }
  },
  "env": {
    "NODE_ENV": "production",
    "SUPABASE_URL": "https://lqyopzfoyllmgfbnjczt.supabase.co",
    "SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k",
    "OPENAI_ASSISTANT_ID": "asst_SIM27MLhW3jL4xRG6SyNzFzc"
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "Access-Control-Allow-Origin", "value": "https://scriptorumbra.ai" },
        { "key": "Access-Control-Allow-Methods", "value": "GET, POST, PUT, DELETE, OPTIONS" },
        { "key": "Access-Control-Allow-Headers", "value": "Content-Type, Authorization" }
      ]
    }
  ]
}
```

### **Step 3: Convert Express Routes to Serverless Functions**

#### **Example: `/api/health.js`**
```javascript
export default function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  res.status(200).json({
    status: 'OK',
    message: 'Scriptor Umbra AI Backend is running',
    timestamp: new Date().toISOString()
  });
}
```

#### **Example: `/api/auth/signup.js`**
```javascript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { email, password, fullName } = req.body;

    // Your existing signup logic here
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName
        }
      }
    });

    if (error) throw error;

    res.status(201).json({ 
      message: 'User created successfully',
      user: data.user 
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}
```

### **Step 4: Deploy to Vercel**

#### **Method 1: GitHub Integration (Recommended)**
1. Upload your converted backend to GitHub
2. Go to https://vercel.com
3. Sign up with GitHub
4. Click **"New Project"**
5. Import your repository
6. Vercel auto-detects and deploys!

#### **Method 2: Vercel CLI**
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy from your backend folder
cd vercel-backend
vercel

# Follow the prompts
```

### **Step 5: Environment Variables**

In Vercel dashboard, add these environment variables:
```
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
OPENAI_API_KEY=your_openai_api_key_here
```

### **Step 6: Get Your Backend URL**

Vercel provides a URL like:
```
https://scriptor-umbra-backend.vercel.app
```

### **Step 7: Update Frontend**

Change the API URL in your frontend:
```javascript
const API_BASE_URL = 'https://scriptor-umbra-backend.vercel.app/api'
```

## 🔧 **Serverless Function Examples**

### **Chat Completion: `/api/chat/completion.js`**
```javascript
import OpenAI from 'openai';
import { createClient } from '@supabase/supabase-js';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { message, threadId } = req.body;
    const authHeader = req.headers.authorization;
    
    // Verify JWT token
    const token = authHeader?.replace('Bearer ', '');
    const { data: { user }, error } = await supabase.auth.getUser(token);
    
    if (error || !user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    // Your existing chat logic here
    const response = await openai.beta.threads.messages.create(threadId, {
      role: 'user',
      content: message
    });

    // Return the AI response
    res.status(200).json({ response: aiResponse });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}
```

## 🎯 **Deployment Checklist**

- [ ] Convert Express routes to serverless functions
- [ ] Create vercel.json configuration
- [ ] Test functions locally with `vercel dev`
- [ ] Deploy to Vercel
- [ ] Add environment variables
- [ ] Test all API endpoints
- [ ] Update frontend API URL
- [ ] Deploy frontend to Vercel or keep on DreamHost

## 🚨 **Vercel Considerations**

### **Advantages**
- **Global CDN**: Fast worldwide access
- **Auto-scaling**: Handles traffic spikes
- **No cold starts**: Functions stay warm
- **Git integration**: Auto-deploy on push

### **Limitations**
- **Function timeout**: 10 seconds on free tier
- **Function size**: 50MB limit
- **Execution time**: 100GB-seconds/month free

### **Best Practices**
- Keep functions small and focused
- Use environment variables for secrets
- Implement proper error handling
- Cache responses when possible

## 🧪 **Testing Serverless Functions**

### **Local Development**
```bash
# Install Vercel CLI
npm i -g vercel

# Start local development server
vercel dev

# Test endpoints
curl http://localhost:3000/api/health
```

### **Production Testing**
```bash
# Test deployed functions
curl https://your-app.vercel.app/api/health
curl -X POST https://your-app.vercel.app/api/auth/signup
```

Vercel is perfect for modern, scalable applications with global reach!

