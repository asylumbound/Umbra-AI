# 🚨 Quick Fix Guide - Scriptor Umbra AI Issues

## ✅ **Good News First!**
- ✅ **Enhanced frontend is working perfectly!** (Dashboard, user profile, conversation management all visible)
- ✅ **Supabase authentication is working!** (User registered and logged in successfully)
- ✅ **Email delivery is working!** (Verification email received)

## 🔧 **Issues to Fix:**

### **Issue 1: Email Verification Redirect Error**
**Problem:** Email verification redirects to `localhost:3000` instead of your domain

**Fix:** Update Supabase redirect URLs
1. Go to https://supabase.com/dashboard
2. Select project: `lqyopzfoyllmgfbnjczt`
3. Go to **Authentication** → **Settings**
4. Update **Site URL** to: `https://scriptorumbra.ai`
5. Update **Redirect URLs** to include:
   ```
   https://scriptorumbra.ai
   https://scriptorumbra.ai/
   https://scriptorumbra.ai/auth/callback
   https://www.scriptorumbra.ai
   https://www.scriptorumbra.ai/
   ```

### **Issue 2: Backend Not Running**
**Problem:** "Failed to create conversation thread" - backend not accessible

**Quick Fix Options:**

#### **Option A: Manual Backend Setup (Recommended)**
Since the deployment script isn't working, let's do it manually:

```bash
# 1. Check if you're in the right directory
pwd
ls -la

# 2. Install Node.js manually
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Verify installation
node --version
npm --version

# 4. Install dependencies
npm install --production

# 5. Create .env file
cp .env.production .env

# 6. Start server
node server.js
```

#### **Option B: Use Cloud Deployment (Fastest)**
Deploy backend to Railway (2 minutes):
1. Go to https://railway.app
2. Sign up with GitHub
3. Click "Deploy from GitHub repo"
4. Upload your backend folder
5. Railway auto-deploys and gives you a URL

#### **Option C: Check Current Directory**
You might not be in the right directory:
```bash
# Check where you are
pwd

# Should be: /home/scriptorumbra/scriptorumbra.ai
# If not, navigate there:
cd /home/scriptorumbra/scriptorumbra.ai

# List files to verify
ls -la
# Should see: server.js, package.json, routes/, etc.
```

## 🧪 **Testing Steps:**

### **After Fixing Supabase Redirect:**
1. **Log out** of your current session
2. **Clear browser cache** (important!)
3. **Register a new test account**
4. **Check email verification** - should redirect to scriptorumbra.ai

### **After Fixing Backend:**
1. **Test backend health:**
   ```bash
   curl http://localhost:3001/health
   ```
2. **Test from frontend:** Try sending a chat message
3. **Check for errors:** Look in browser console (F12)

## 🚀 **Quick Backend Test Commands:**

```bash
# Check if Node.js is installed
node --version

# Check if you're in the right directory
ls -la | grep server.js

# Install dependencies if needed
npm install

# Start server manually
node server.js

# In another terminal, test health
curl http://localhost:3001/health
```

## 🎯 **Expected Results:**

### **After Supabase Fix:**
- Email verification links redirect to scriptorumbra.ai
- No more localhost:3000 errors
- Smooth authentication flow

### **After Backend Fix:**
- Chat messages get AI responses
- No "Failed to create conversation thread" errors
- Conversation history saves properly

## 🚨 **If Still Having Issues:**

### **Backend Won't Start:**
```bash
# Check what's using port 3001
sudo lsof -i :3001

# Kill any existing process
sudo kill -9 [PID]

# Try starting again
node server.js
```

### **Dependencies Won't Install:**
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules and try again
rm -rf node_modules package-lock.json
npm install
```

### **Permission Issues:**
```bash
# Fix ownership
sudo chown -R $USER:$USER .

# Make scripts executable
chmod +x *.sh
```

The enhanced frontend is working beautifully - we just need to get the backend connected and fix the email redirect!

