# Scriptor Umbra AI - API Configuration Guide

This guide explains how to configure and integrate different AI APIs with Scriptor Umbra AI.

## 🎯 Overview

Scriptor Umbra AI is designed with a modular architecture that supports multiple AI providers. While OpenAI is the primary provider, the system can be extended to support Anthropic Claude, Mistral AI, and other providers.

## 🔑 OpenAI Configuration (Primary)

### Getting Your API Key

1. **Create an OpenAI Account**
   - Visit https://platform.openai.com/
   - Sign up or log in to your account

2. **Generate API Key**
   - Go to https://platform.openai.com/api-keys
   - Click "Create new secret key"
   - Copy the key (it starts with `sk-`)
   - Store it securely - you won't be able to see it again

3. **Set Up Billing**
   - Add a payment method at https://platform.openai.com/account/billing
   - Set usage limits to control costs
   - Monitor your usage regularly

### Configuration

Add your OpenAI API key to the backend `.env` file:

```env
OPENAI_API_KEY=sk-your-actual-api-key-here
```

### Supported Models

The application currently supports these OpenAI models:

- **GPT-3.5 Turbo** (Default): Fast and cost-effective
- **GPT-4**: More capable but slower and more expensive
- **GPT-4 Turbo**: Latest model with improved performance

To change the default model, edit `routes/chat.js`:

```javascript
const completion = await openai.chat.completions.create({
  model: 'gpt-4', // Change from 'gpt-3.5-turbo'
  messages: messages,
  max_tokens: 1000,
  temperature: 0.7,
  stream: false
});
```

### Usage Limits and Costs

Monitor your usage to avoid unexpected charges:

- **GPT-3.5 Turbo**: ~$0.002 per 1K tokens
- **GPT-4**: ~$0.03 per 1K tokens
- **GPT-4 Turbo**: ~$0.01 per 1K tokens

Set up usage alerts in your OpenAI dashboard.

## 🤖 Anthropic Claude Configuration (Future)

### Setup Process

1. **Get API Access**
   - Visit https://console.anthropic.com/
   - Request API access
   - Generate an API key

2. **Install Dependencies**
   ```bash
   cd scriptor-umbra-backend
   npm install @anthropic-ai/sdk
   ```

3. **Environment Configuration**
   ```env
   ANTHROPIC_API_KEY=your_anthropic_key_here
   ```

### Implementation Example

Add to `routes/chat.js`:

```javascript
const Anthropic = require('@anthropic-ai/sdk');

let anthropic;
if (process.env.ANTHROPIC_API_KEY) {
  anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });
}

// In the completion endpoint
if (req.body.provider === 'anthropic' && anthropic) {
  const message = await anthropic.messages.create({
    model: 'claude-3-sonnet-20240229',
    max_tokens: 1000,
    messages: messages
  });
  
  const aiResponse = message.content[0].text;
  // Handle response...
}
```

## 🌟 Mistral AI Configuration (Future)

### Setup Process

1. **Get API Access**
   - Visit https://console.mistral.ai/
   - Create an account and generate API key

2. **Install Dependencies**
   ```bash
   npm install @mistralai/mistralai
   ```

3. **Environment Configuration**
   ```env
   MISTRAL_API_KEY=your_mistral_key_here
   ```

### Implementation Example

```javascript
const MistralClient = require('@mistralai/mistralai');

let mistral;
if (process.env.MISTRAL_API_KEY) {
  mistral = new MistralClient(process.env.MISTRAL_API_KEY);
}

// Usage in completion endpoint
if (req.body.provider === 'mistral' && mistral) {
  const chatResponse = await mistral.chat({
    model: 'mistral-medium',
    messages: messages,
  });
  
  const aiResponse = chatResponse.choices[0].message.content;
  // Handle response...
}
```

## 🔧 Advanced Configuration

### Custom System Prompts

Modify the system prompt in `routes/chat.js` to customize the AI's behavior:

```javascript
const messages = [
  {
    role: 'system',
    content: `You are Scriptor Umbra AI, an expert ghostwriting assistant specializing in:

- Academic and research writing
- Business and marketing content
- Creative writing and storytelling
- Technical documentation
- SEO-optimized content

Your writing style should be:
- Professional yet engaging
- Clear and concise
- Tailored to the target audience
- Well-structured and organized

Always ask clarifying questions when the request is ambiguous and provide actionable advice for improving content.`
  },
  // ... rest of conversation
];
```

### Temperature and Creativity Settings

Adjust the AI's creativity level:

```javascript
const completion = await openai.chat.completions.create({
  model: 'gpt-3.5-turbo',
  messages: messages,
  max_tokens: 1000,
  temperature: 0.7, // 0.0 = deterministic, 1.0 = very creative
  top_p: 1.0,       // Nucleus sampling
  frequency_penalty: 0.0, // Reduce repetition
  presence_penalty: 0.0,  // Encourage new topics
  stream: false
});
```

### Token Management

Implement token counting to manage costs:

```javascript
const { encode } = require('gpt-3-encoder');

function countTokens(text) {
  return encode(text).length;
}

// Before API call
const totalTokens = messages.reduce((sum, msg) => 
  sum + countTokens(msg.content), 0
);

if (totalTokens > 3000) {
  // Truncate conversation history
  messages = messages.slice(-5); // Keep last 5 messages
}
```

### Response Streaming

For real-time responses, implement streaming:

```javascript
const completion = await openai.chat.completions.create({
  model: 'gpt-3.5-turbo',
  messages: messages,
  max_tokens: 1000,
  temperature: 0.7,
  stream: true // Enable streaming
});

for await (const chunk of completion) {
  const content = chunk.choices[0]?.delta?.content || '';
  if (content) {
    // Send chunk to frontend via WebSocket or SSE
    res.write(`data: ${JSON.stringify({ content })}\n\n`);
  }
}
```

## 🛡️ Security Best Practices

### API Key Security

1. **Never commit API keys to version control**
2. **Use environment variables for all sensitive data**
3. **Rotate API keys regularly**
4. **Set up usage alerts and limits**
5. **Use different keys for development and production**

### Rate Limiting

Configure appropriate rate limits:

```javascript
const rateLimit = require('express-rate-limit');

const chatLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // Limit each IP to 50 requests per windowMs
  message: {
    error: 'Too many chat requests, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/chat', chatLimiter);
```

### Input Validation

Validate all inputs before sending to AI APIs:

```javascript
const { body, validationResult } = require('express-validator');

const validateChatInput = [
  body('message')
    .isLength({ min: 1, max: 4000 })
    .withMessage('Message must be between 1 and 4000 characters'),
  body('conversation')
    .optional()
    .isArray({ max: 20 })
    .withMessage('Conversation history limited to 20 messages'),
];

app.post('/api/chat/completion', validateChatInput, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  // Process request...
});
```

## 📊 Monitoring and Analytics

### Usage Tracking

Track API usage for billing and optimization:

```javascript
const usage = {
  timestamp: new Date(),
  model: 'gpt-3.5-turbo',
  tokens_used: completion.usage.total_tokens,
  cost: completion.usage.total_tokens * 0.000002, // Approximate cost
  user_id: req.user?.id || 'anonymous'
};

// Log to database or analytics service
console.log('API Usage:', usage);
```

### Error Monitoring

Implement comprehensive error tracking:

```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

// In error handling
catch (error) {
  logger.error('OpenAI API Error', {
    error: error.message,
    code: error.code,
    type: error.type,
    timestamp: new Date()
  });
  
  // Handle specific error types
  if (error.code === 'insufficient_quota') {
    return res.status(429).json({
      error: 'API quota exceeded',
      message: 'Please check your billing settings.'
    });
  }
}
```

## 🔄 Provider Switching

### Dynamic Provider Selection

Allow users to choose their preferred AI provider:

```javascript
// Frontend: Add provider selection
const [selectedProvider, setSelectedProvider] = useState('openai');

// Backend: Handle provider routing
const getAIResponse = async (provider, messages) => {
  switch (provider) {
    case 'openai':
      return await getOpenAIResponse(messages);
    case 'anthropic':
      return await getAnthropicResponse(messages);
    case 'mistral':
      return await getMistralResponse(messages);
    default:
      throw new Error('Unsupported provider');
  }
};
```

### Fallback Providers

Implement automatic fallback for reliability:

```javascript
const providers = ['openai', 'anthropic', 'mistral'];

for (const provider of providers) {
  try {
    const response = await getAIResponse(provider, messages);
    return response;
  } catch (error) {
    console.log(`Provider ${provider} failed, trying next...`);
    continue;
  }
}

throw new Error('All providers failed');
```

## 📋 Configuration Checklist

### Initial Setup
- [ ] Obtain API keys from chosen providers
- [ ] Configure environment variables
- [ ] Test API connections
- [ ] Set up usage monitoring
- [ ] Configure rate limiting

### Security
- [ ] Secure API key storage
- [ ] Implement input validation
- [ ] Set up error handling
- [ ] Configure CORS properly
- [ ] Enable HTTPS in production

### Optimization
- [ ] Configure appropriate model settings
- [ ] Implement token management
- [ ] Set up caching if needed
- [ ] Monitor costs and usage
- [ ] Optimize system prompts

### Monitoring
- [ ] Set up logging
- [ ] Configure error tracking
- [ ] Monitor API usage
- [ ] Set up alerts for issues
- [ ] Track performance metrics

---

This configuration guide ensures your Scriptor Umbra AI deployment is secure, efficient, and ready for production use.

