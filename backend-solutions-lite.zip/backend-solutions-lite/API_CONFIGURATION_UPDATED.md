# Scriptor Umbra AI - API Configuration Guide

This guide provides detailed instructions for configuring the OpenAI Assistant API integration and setting up your custom ghostwriting assistant.

## OpenAI Assistant API Setup

### Step 1: Create OpenAI Assistant

1. **Access OpenAI Platform**
   - Go to https://platform.openai.com/assistants
   - Sign in to your OpenAI account
   - Ensure you have API access and sufficient credits

2. **Create New Assistant**
   - Click "Create Assistant"
   - Choose a name: "Scriptor Umbra AI"
   - Select model: GPT-4 (recommended) or GPT-3.5-turbo

3. **Configure Assistant Instructions**
   Use the following optimized instructions for ghostwriting:

```text
You are Scriptor Umbra AI, a professional ghostwriting assistant specializing in creating exceptional written content. Your expertise includes:

CORE SPECIALIZATIONS:
- Article writing and editing for publications, blogs, and media
- Book development including manuscripts, chapters, and long-form content
- Copywriting for marketing, sales, and promotional materials
- Content strategy and editorial planning
- Research integration and fact-checking
- Style adaptation and voice matching for different audiences

WRITING APPROACH:
- Provide detailed, professional writing assistance with clear structure
- Create engaging content that maintains reader interest
- Ensure proper formatting and readability
- Maintain the user's intended tone and style preferences
- Offer constructive feedback and improvement suggestions
- Support both creative and technical writing projects

INTERACTION STYLE:
- Ask clarifying questions when requirements are unclear
- Provide multiple options when appropriate
- Explain your reasoning for writing choices
- Offer revision suggestions and alternatives
- Maintain a professional yet approachable tone

Always prioritize quality, clarity, and the user's specific goals for each writing project.
```

4. **Configure Assistant Settings**
   - **Temperature**: 0.7 (balanced creativity and consistency)
   - **Top P**: 1.0 (full vocabulary access)
   - **Response Format**: Text (default)
   - **Tools**: None required for basic ghostwriting

5. **Save and Copy Assistant ID**
   - Click "Save" to create the assistant
   - Copy the Assistant ID (format: `asst_xxxxxxxxxxxxxxxxx`)
   - Store this ID securely for environment configuration

### Step 2: Environment Configuration

1. **Backend Configuration**
   Update your `.env` file in the backend directory:

```env
# OpenAI Assistant API Configuration
OPENAI_API_KEY=sk-proj-your_actual_api_key_here
ASSISTANT_ID=asst_your_assistant_id_here

# Server Configuration
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

# Security Settings
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

2. **Production Environment Variables**
   For deployment platforms (Vercel, Railway, Render):
   - `OPENAI_API_KEY`: Your OpenAI API key
   - `ASSISTANT_ID`: Your assistant ID from step 1
   - `FRONTEND_URL`: Your deployed frontend URL
   - `NODE_ENV`: production

### Step 3: API Key Management

1. **OpenAI API Key Requirements**
   - Valid OpenAI account with API access
   - Sufficient credits for Assistant API usage
   - API key with appropriate permissions

2. **Security Best Practices**
   - Never commit API keys to version control
   - Use environment variables for all sensitive data
   - Rotate API keys regularly
   - Monitor API usage and costs

3. **API Usage Monitoring**
   - Check usage at https://platform.openai.com/usage
   - Set up billing alerts for cost control
   - Monitor rate limits and quotas

## Assistant API Features

### Thread Management

The Assistant API provides persistent conversation threads that maintain context across multiple interactions:

1. **Automatic Thread Creation**
   - New threads created automatically for first-time users
   - Thread IDs returned with each response
   - Threads persist for 24 hours by default

2. **Thread Persistence**
   - Conversation history maintained within threads
   - Context preserved across sessions
   - Automatic cleanup of old threads

3. **Thread Operations**
   - Create new thread: `POST /api/chat/thread/new`
   - Send message: `POST /api/chat/completion`
   - Get history: `GET /api/chat/thread/:threadId/messages`

### Message Processing

1. **Message Flow**
   ```
   User Message → Thread → Assistant Processing → Response → Thread Update
   ```

2. **Response Generation**
   - Messages processed through OpenAI Assistant API
   - Responses generated based on assistant instructions
   - Context maintained throughout conversation

3. **Error Handling**
   - Automatic retry for transient failures
   - Graceful degradation for API issues
   - User-friendly error messages

## Advanced Configuration

### Custom Assistant Instructions

For specialized use cases, customize the assistant instructions:

1. **Technical Writing Focus**
```text
You are a technical writing specialist focusing on:
- Documentation and user guides
- API documentation and developer resources
- Technical articles and whitepapers
- Process documentation and procedures
```

2. **Creative Writing Focus**
```text
You are a creative writing assistant specializing in:
- Fiction writing and storytelling
- Character development and dialogue
- Plot structure and narrative flow
- Creative non-fiction and memoirs
```

3. **Business Writing Focus**
```text
You are a business writing expert focusing on:
- Executive communications and reports
- Proposal writing and presentations
- Marketing copy and sales materials
- Internal communications and policies
```

### Model Selection

Choose the appropriate model based on your needs:

1. **GPT-4** (Recommended)
   - Best quality and reasoning
   - Higher cost per token
   - Ideal for complex writing tasks

2. **GPT-3.5-turbo**
   - Good quality at lower cost
   - Faster response times
   - Suitable for simpler tasks

### Performance Optimization

1. **Response Time Optimization**
   - Use appropriate model for task complexity
   - Optimize assistant instructions length
   - Implement proper error handling

2. **Cost Management**
   - Monitor token usage
   - Set appropriate rate limits
   - Use caching where possible

3. **Quality Assurance**
   - Test assistant responses regularly
   - Update instructions based on feedback
   - Monitor conversation quality

## Troubleshooting

### Common Issues

1. **Authentication Errors**
   ```
   Error: 401 Unauthorized
   Solution: Verify API key is correct and active
   ```

2. **Assistant Not Found**
   ```
   Error: Assistant ID not found
   Solution: Check assistant ID and ensure assistant exists
   ```

3. **Rate Limiting**
   ```
   Error: 429 Too Many Requests
   Solution: Implement proper rate limiting and retry logic
   ```

4. **Thread Errors**
   ```
   Error: Thread not found
   Solution: Create new thread or handle expired threads
   ```

### Debugging Steps

1. **Check API Configuration**
   - Verify environment variables are set
   - Test API key with simple request
   - Confirm assistant ID is valid

2. **Monitor API Responses**
   - Check server logs for errors
   - Verify request/response format
   - Test endpoints individually

3. **Frontend Integration**
   - Check browser console for errors
   - Verify API endpoint URLs
   - Test network connectivity

### Support Resources

1. **OpenAI Documentation**
   - Assistant API Guide: https://platform.openai.com/docs/assistants
   - API Reference: https://platform.openai.com/docs/api-reference

2. **Community Support**
   - OpenAI Community Forum
   - GitHub Issues for project-specific problems
   - Stack Overflow for technical questions

---

**Configuration Complete!**

Your Scriptor Umbra AI is now configured with the OpenAI Assistant API for advanced ghostwriting assistance with persistent conversation threads.

