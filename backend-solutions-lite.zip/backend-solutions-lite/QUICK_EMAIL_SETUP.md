# 📩 Quick Email Auth Setup - scriptorumbra.ai

## 🚀 **5-Minute Setup Checklist**

### **Step 1: Access Supabase Dashboard**
1. Go to https://supabase.com/dashboard
2. Select project: `lqyopzfoyllmgfbnjczt`
3. Click **Authentication** → **Providers**

### **Step 2: Configure Email Provider**
In the **Email** section:
- ✅ **Enable email provider**: ON
- ✅ **Enable email confirmations**: ON
- ✅ **Enable email change confirmations**: ON

### **Step 3: Set URLs**
Go to **Authentication** → **Settings**:

**Site URL:**
```
https://scriptorumbra.ai
```

**Redirect URLs (add all of these):**
```
https://scriptorumbra.ai
https://scriptorumbra.ai/
https://scriptorumbra.ai/auth/callback
https://scriptorumbra.ai/dashboard
https://www.scriptorumbra.ai
https://www.scriptorumbra.ai/
https://www.scriptorumbra.ai/auth/callback
https://www.scriptorumbra.ai/dashboard
```

### **Step 4: Save Settings**
- Click **Save** after each configuration
- Wait for changes to propagate (30-60 seconds)

### **Step 5: Test**
1. Go to https://scriptorumbra.ai
2. Try signing up with a test email
3. Check email for confirmation link
4. Click link and verify redirect

## ✅ **Success Indicators**
- Users can sign up successfully
- Confirmation emails are received
- Email links redirect to your site
- Login works after confirmation

## 🚨 **Common Issues**
- **"Invalid redirect URL"**: Check URLs are exactly as listed above
- **No email received**: Check spam folder, verify SMTP settings
- **CORS error**: Ensure Site URL matches your domain exactly

## 📞 **Quick Help**
If something doesn't work:
1. Double-check all URLs are saved
2. Try with a fresh email address
3. Check browser console for errors
4. Wait 1-2 minutes for settings to propagate

Your email authentication should be working in under 5 minutes!

