# 📩 Supabase Email Authentication Configuration Guide

## 🎯 **Complete Setup for scriptorumbra.ai**

This guide will walk you through configuring email authentication in your Supabase project for your domain.

## 🔧 **Step-by-Step Configuration**

### **Step 1: Access Supabase Dashboard**
1. Go to https://supabase.com/dashboard
2. Login to your account
3. Select your project: `lqyopzfoyllmgfbnjczt`

### **Step 2: Navigate to Authentication Settings**
1. In the left sidebar, click **"Authentication"**
2. Click **"Providers"** tab
3. Look for the **"Email"** section

### **Step 3: Configure Email Provider**
In the Email section, configure these settings:

#### **✅ Email Sign-in Settings**
- **Enable email provider**: ✅ **ON**
- **Enable email confirmations**: ✅ **ON** (Recommended for security)
- **Enable email change confirmations**: ✅ **ON**
- **Enable secure email change**: ✅ **ON**

#### **✅ Email Templates (Optional but Recommended)**
- **Confirm signup**: Use default or customize
- **Invite user**: Use default or customize  
- **Magic link**: Use default or customize
- **Change email address**: Use default or customize
- **Reset password**: Use default or customize

### **Step 4: Configure Site URL and Redirect URLs**
This is the **most important step** for your domain:

#### **Site URL**
```
https://scriptorumbra.ai
```

#### **Redirect URLs**
Add these URLs (one per line):
```
https://scriptorumbra.ai
https://scriptorumbra.ai/
https://scriptorumbra.ai/auth/callback
https://scriptorumbra.ai/dashboard
https://www.scriptorumbra.ai
https://www.scriptorumbra.ai/
https://www.scriptorumbra.ai/auth/callback
https://www.scriptorumbra.ai/dashboard
```

**Why these URLs?**
- Base domain for general redirects
- `/auth/callback` for authentication callbacks
- `/dashboard` for post-login redirects
- Both www and non-www versions for compatibility

### **Step 5: Additional Security Settings**
Go to **Authentication** → **Settings** and configure:

#### **General Settings**
- **Site URL**: `https://scriptorumbra.ai`
- **JWT expiry**: `3600` (1 hour, default)
- **Refresh token rotation**: ✅ **ON**
- **Reuse interval**: `10` (seconds)

#### **Email Rate Limits**
- **Email rate limit**: `3` per hour (prevents spam)
- **SMS rate limit**: Not needed for email auth

#### **Security Settings**
- **Enable database webhooks**: ✅ **ON**
- **Enable realtime**: ✅ **ON** (if using real-time features)

## 📧 **Email Configuration Options**

### **Option 1: Use Supabase SMTP (Recommended for Testing)**
- **Provider**: Supabase built-in
- **Limitations**: 3 emails per hour for free tier
- **Best for**: Development and testing

### **Option 2: Custom SMTP (Recommended for Production)**
If you want to use your own email service:

1. Go to **Authentication** → **Settings**
2. Scroll to **SMTP Settings**
3. Configure your email provider:

#### **Gmail SMTP Example**
```
SMTP Host: smtp.gmail.com
SMTP Port: 587
SMTP User: your-email@gmail.com
SMTP Pass: your-app-password
Sender Name: Scriptor Umbra AI
Sender Email: noreply@scriptorumbra.ai
```

#### **SendGrid SMTP Example**
```
SMTP Host: smtp.sendgrid.net
SMTP Port: 587
SMTP User: apikey
SMTP Pass: your-sendgrid-api-key
Sender Name: Scriptor Umbra AI
Sender Email: noreply@scriptorumbra.ai
```

## 🎨 **Customize Email Templates**

### **Signup Confirmation Email**
```html
<h2>Welcome to Scriptor Umbra AI!</h2>
<p>Thanks for signing up! Please confirm your email address by clicking the link below:</p>
<p><a href="{{ .ConfirmationURL }}">Confirm your account</a></p>
<p>If you didn't create an account, you can safely ignore this email.</p>
<p>Best regards,<br>The Scriptor Umbra AI Team</p>
```

### **Password Reset Email**
```html
<h2>Reset Your Password</h2>
<p>You requested to reset your password for Scriptor Umbra AI.</p>
<p><a href="{{ .ConfirmationURL }}">Reset your password</a></p>
<p>If you didn't request this, you can safely ignore this email.</p>
<p>Best regards,<br>The Scriptor Umbra AI Team</p>
```

## 🧪 **Testing Your Configuration**

### **Test Email Signup Flow**
1. Go to https://scriptorumbra.ai
2. Click **"Sign Up"**
3. Enter a test email and password
4. Check your email for confirmation
5. Click the confirmation link
6. Verify you're redirected back to your site

### **Test Password Reset Flow**
1. Go to login page
2. Click **"Forgot Password"**
3. Enter your email
4. Check email for reset link
5. Click reset link
6. Set new password
7. Verify login works

## 🔍 **Troubleshooting Common Issues**

### **Issue: "Invalid redirect URL"**
**Solution**: Make sure your redirect URL is exactly listed in the Supabase settings

### **Issue: "Email not confirmed"**
**Solution**: 
- Check spam folder
- Verify SMTP settings
- Check email rate limits

### **Issue: "Authentication failed"**
**Solution**:
- Verify Site URL matches your domain exactly
- Check that email confirmations are enabled
- Ensure user confirmed their email

### **Issue: "CORS error"**
**Solution**:
- Add your domain to redirect URLs
- Check that Site URL is set correctly
- Verify frontend is using correct Supabase URL

## 📋 **Configuration Checklist**

### **✅ Email Provider Settings**
- [ ] Email provider enabled
- [ ] Email confirmations enabled
- [ ] Email change confirmations enabled
- [ ] Secure email change enabled

### **✅ URL Configuration**
- [ ] Site URL: `https://scriptorumbra.ai`
- [ ] Redirect URLs include all necessary paths
- [ ] Both www and non-www versions added

### **✅ Security Settings**
- [ ] JWT expiry configured
- [ ] Refresh token rotation enabled
- [ ] Email rate limits set

### **✅ SMTP Configuration (Optional)**
- [ ] SMTP provider configured
- [ ] Sender email set
- [ ] Email templates customized

### **✅ Testing**
- [ ] Signup flow tested
- [ ] Email confirmation tested
- [ ] Password reset tested
- [ ] Login flow tested

## 🚀 **Production Recommendations**

### **For High Volume**
1. **Use custom SMTP** (SendGrid, Mailgun, etc.)
2. **Set up proper SPF/DKIM** records
3. **Monitor email deliverability**
4. **Set up email analytics**

### **For Security**
1. **Enable all confirmation emails**
2. **Set reasonable rate limits**
3. **Monitor authentication logs**
4. **Set up alerts for suspicious activity**

### **For User Experience**
1. **Customize email templates** with your branding
2. **Set up proper sender name** and email
3. **Test all email flows** regularly
4. **Provide clear error messages**

## 📞 **Need Help?**

If you encounter issues:
1. Check the Supabase logs in your dashboard
2. Verify all URLs are correctly configured
3. Test with a fresh email address
4. Check browser console for errors

Your email authentication should now be fully configured for https://scriptorumbra.ai!

