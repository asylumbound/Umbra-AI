# 🚀 SSH Deployment Guide for Scriptor Umbra AI Backend

## 📋 Prerequisites

Before starting the SSH deployment process, ensure you have:

- **SSH access** to your server (username, password/key, IP address)
- **Root or sudo privileges** on the target server
- **Node.js 18+** installed (we'll verify and install if needed)
- **Your deployment package** (`scriptor-umbra-ai-dragdrop-complete.zip`)

## 🔐 Step 1: Connect to Your Server

### Connect via SSH
```bash
# Replace with your actual server details
ssh username@your-server-ip

# Example:
ssh root@192.168.1.100
# or
ssh ubuntu@your-domain.com
```

### If using SSH key authentication:
```bash
ssh -i /path/to/your-private-key username@your-server-ip

# Example:
ssh -i ~/.ssh/id_rsa ubuntu@your-server.com
```

### For first-time connections:
- You'll see a message about host authenticity
- Type `yes` to continue
- Enter your password when prompted

## 📁 Step 2: Upload Your Backend Files

### Option A: Upload via SCP (Recommended)

**From your local machine** (open a new terminal, don't close SSH):

```bash
# Navigate to where you extracted the deployment package
cd /path/to/extracted/scriptor-umbra-dragdrop/

# Upload the backend folder to your server
scp -r BACKEND_STANDALONE/ username@your-server-ip:/home/username/

# Example:
scp -r BACKEND_STANDALONE/ ubuntu@192.168.1.100:/home/ubuntu/scriptor-backend/
```

### Option B: Upload via SFTP

```bash
# Connect via SFTP
sftp username@your-server-ip

# Navigate to destination directory
cd /home/username/

# Upload the backend folder
put -r /local/path/to/BACKEND_STANDALONE/ scriptor-backend/

# Exit SFTP
exit
```

### Option C: Download directly on server

**Back in your SSH session:**

```bash
# If you have the zip file hosted somewhere
wget https://your-domain.com/scriptor-umbra-ai-dragdrop-complete.zip

# Or use curl
curl -O https://your-domain.com/scriptor-umbra-ai-dragdrop-complete.zip

# Extract the zip file
unzip scriptor-umbra-ai-dragdrop-complete.zip

# Navigate to backend folder
cd scriptor-umbra-dragdrop/BACKEND_STANDALONE/
```

## 🔧 Step 3: Verify and Install Node.js

### Check if Node.js is installed:
```bash
node --version
npm --version
```

### If Node.js is NOT installed or version is below 18:

**For Ubuntu/Debian:**
```bash
# Update package list
sudo apt update

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

**For CentOS/RHEL/Amazon Linux:**
```bash
# Install Node.js 18.x
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Verify installation
node --version
npm --version
```

**For other systems:**
```bash
# Download and install manually
wget https://nodejs.org/dist/v18.19.0/node-v18.19.0-linux-x64.tar.xz
tar -xf node-v18.19.0-linux-x64.tar.xz
sudo mv node-v18.19.0-linux-x64 /opt/nodejs
sudo ln -s /opt/nodejs/bin/node /usr/local/bin/node
sudo ln -s /opt/nodejs/bin/npm /usr/local/bin/npm
```

## 📦 Step 4: Navigate to Backend Directory

```bash
# Navigate to your uploaded backend directory
cd /home/username/scriptor-backend/

# Or if you extracted the zip:
cd /home/username/scriptor-umbra-dragdrop/BACKEND_STANDALONE/

# Verify files are present
ls -la

# You should see:
# - server.js
# - package.json
# - routes/
# - .env
# - deploy.sh
# - deploy.bat
```

## 🛠️ Step 5: Install Dependencies

```bash
# Install all required dependencies
npm install

# This will:
# - Read package.json
# - Download all dependencies to node_modules/
# - May take 1-3 minutes depending on server speed
```

### If you encounter permission errors:
```bash
# Fix npm permissions
sudo chown -R $(whoami) ~/.npm
sudo chown -R $(whoami) /home/username/scriptor-backend/

# Try again
npm install
```

### If npm install fails:
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules if it exists
rm -rf node_modules/

# Try installing again
npm install
```

## ⚙️ Step 6: Configure Environment

### Verify your environment file:
```bash
# Check if .env file exists and has correct content
cat .env

# You should see:
# OPENAI_API_KEY=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
# ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
# PORT=3001
# NODE_ENV=production
```

### If .env file is missing:
```bash
# Copy from production template
cp .env.production .env

# Or create manually
nano .env

# Add the following content:
OPENAI_API_KEY=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
ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
PORT=3001
NODE_ENV=production
FRONTEND_URL=https://yourdomain.com

# Save and exit (Ctrl+X, then Y, then Enter in nano)
```

## 🚀 Step 7: Start the Backend

### Option A: Using the deployment script (Recommended)
```bash
# Make the script executable
chmod +x deploy.sh

# Run the deployment script
./deploy.sh

# The script will:
# - Check Node.js installation
# - Install dependencies (if needed)
# - Verify environment configuration
# - Find available port
# - Start the server
```

### Option B: Manual startup
```bash
# Start the server manually
npm start

# You should see output like:
# > scriptor-umbra-backend@1.0.0 start
# > node server.js
# 
# 🚀 Scriptor Umbra AI Backend starting...
# ✅ Environment loaded
# ✅ OpenAI API configured
# ✅ Assistant ID: asst_SIM27MLhW3jL4xRG6SyNzFzc
# 🌐 Server running on port 3001
# 📡 Health check: http://localhost:3001/health
```

### Option C: Production startup with PM2
```bash
# Install PM2 globally
sudo npm install -g pm2

# Start with PM2
pm2 start server.js --name "scriptor-umbra"

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup

# Check status
pm2 status
```

## 🧪 Step 8: Test Your Deployment

### Test the health endpoint:
```bash
# Test from the server itself
curl http://localhost:3001/health

# You should get a response like:
# {"status":"healthy","timestamp":"2025-06-22T17:45:00.000Z","assistant":"asst_SIM27MLhW3jL4xRG6SyNzFzc"}
```

### Test the API endpoint:
```bash
# Test the chat completion endpoint
curl -X POST http://localhost:3001/api/chat/completion \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, can you help me write?"}'

# You should get an AI response
```

### Test from external access:
```bash
# From your local machine, test external access
curl http://your-server-ip:3001/health

# If this fails, you may need to configure firewall (see next section)
```

## 🔥 Step 9: Configure Firewall (if needed)

### For Ubuntu/Debian (UFW):
```bash
# Check firewall status
sudo ufw status

# Allow port 3001
sudo ufw allow 3001

# Enable firewall if not enabled
sudo ufw enable

# Check status again
sudo ufw status
```

### For CentOS/RHEL (firewalld):
```bash
# Check firewall status
sudo firewall-cmd --state

# Allow port 3001
sudo firewall-cmd --permanent --add-port=3001/tcp
sudo firewall-cmd --reload

# Check open ports
sudo firewall-cmd --list-ports
```

### For systems with iptables:
```bash
# Allow port 3001
sudo iptables -A INPUT -p tcp --dport 3001 -j ACCEPT

# Save iptables rules (command varies by system)
sudo iptables-save > /etc/iptables/rules.v4
```

## 🌐 Step 10: Configure Reverse Proxy (Optional but Recommended)

### Install and configure Nginx:
```bash
# Install Nginx
sudo apt update
sudo apt install nginx

# Create configuration file
sudo nano /etc/nginx/sites-available/scriptor-umbra

# Add the following configuration:
server {
    listen 80;
    server_name your-domain.com;

    location /api/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    location / {
        root /var/www/html;
        try_files $uri $uri/ /index.html;
    }
}

# Enable the site
sudo ln -s /etc/nginx/sites-available/scriptor-umbra /etc/nginx/sites-enabled/

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

## 🔒 Step 11: Enable SSL (Recommended)

### Using Certbot (Let's Encrypt):
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com

# Test automatic renewal
sudo certbot renew --dry-run
```

## 📊 Step 12: Monitor and Manage

### Check if service is running:
```bash
# If using PM2
pm2 status
pm2 logs scriptor-umbra

# If running manually, check process
ps aux | grep node

# Check port usage
sudo netstat -tlnp | grep 3001
```

### View logs:
```bash
# If using PM2
pm2 logs scriptor-umbra --lines 50

# If running manually, logs go to console
# You can redirect to file:
npm start > /var/log/scriptor-umbra.log 2>&1 &
```

### Restart the service:
```bash
# If using PM2
pm2 restart scriptor-umbra

# If running manually
# Find the process ID
ps aux | grep node
# Kill the process
kill [PID]
# Start again
npm start
```

## ✅ Verification Checklist

- [ ] SSH connection successful
- [ ] Backend files uploaded to server
- [ ] Node.js 18+ installed and working
- [ ] Dependencies installed (`npm install` completed)
- [ ] Environment file (.env) configured correctly
- [ ] Backend service started successfully
- [ ] Health check responds: `curl http://localhost:3001/health`
- [ ] API endpoint responds: `curl -X POST http://localhost:3001/api/chat/completion`
- [ ] Firewall configured to allow port 3001
- [ ] External access working: `curl http://your-server-ip:3001/health`
- [ ] (Optional) Reverse proxy configured
- [ ] (Optional) SSL certificate installed

## 🎉 Success!

Your Scriptor Umbra AI backend is now running on your server via SSH deployment. The API is accessible at:

- **Health Check**: `http://your-server-ip:3001/health`
- **Chat API**: `http://your-server-ip:3001/api/chat/completion`
- **Thread Management**: `http://your-server-ip:3001/api/chat/thread/`

Your frontend can now connect to this backend URL to provide the complete AI ghostwriting experience.

---

**Need help?** Check the troubleshooting section below or refer to the complete documentation in your deployment package.



## 🌟 DreamHost VPS Specific Instructions

### Connecting to Your DreamHost VPS

```bash
# Connect to your DreamHost VPS
ssh username@vps64698.dreamhostps.com

# Replace 'username' with your actual DreamHost username
# Example:
ssh meka@vps64698.dreamhostps.com
```

### DreamHost VPS Environment Details

DreamHost VPS servers typically come with:
- **Ubuntu 20.04 or 22.04 LTS**
- **Node.js may or may not be pre-installed**
- **Standard user account with sudo privileges**
- **Apache web server pre-configured**
- **Home directory**: `/home/username/`
- **Web directory**: `/home/username/yourdomain.com/`

### Step-by-Step for DreamHost VPS

#### 1. Connect and Check Environment
```bash
# Connect to your VPS
ssh username@vps64698.dreamhostps.com

# Check current directory
pwd
# Should show: /home/username

# Check if Node.js is installed
node --version
npm --version

# Check available disk space
df -h

# Check system info
uname -a
```

#### 2. Install Node.js (if needed)
```bash
# DreamHost VPS usually needs Node.js installation
# Update package list first
sudo apt update

# Install Node.js 18.x (recommended)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

#### 3. Create Backend Directory
```bash
# Create a directory for your backend
mkdir -p ~/scriptor-umbra-backend
cd ~/scriptor-umbra-backend

# Check you're in the right place
pwd
# Should show: /home/username/scriptor-umbra-backend
```

#### 4. Upload Backend Files to DreamHost

**From your local machine** (new terminal window):

```bash
# Navigate to your extracted deployment package
cd /path/to/scriptor-umbra-dragdrop/

# Upload backend to DreamHost VPS
scp -r BACKEND_STANDALONE/* username@vps64698.dreamhostps.com:/home/username/scriptor-umbra-backend/

# Example:
scp -r BACKEND_STANDALONE/* meka@vps64698.dreamhostps.com:/home/meka/scriptor-umbra-backend/
```

#### 5. Back to SSH - Install Dependencies
```bash
# Make sure you're in the backend directory
cd ~/scriptor-umbra-backend

# List files to verify upload
ls -la
# You should see: server.js, package.json, routes/, .env, etc.

# Install dependencies
npm install

# This may take 2-3 minutes on DreamHost VPS
```

#### 6. Configure for DreamHost
```bash
# Check your .env file
cat .env

# If you need to edit it:
nano .env

# Make sure it contains:
OPENAI_API_KEY=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
ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
PORT=3001
NODE_ENV=production
FRONTEND_URL=https://yourdomain.com

# Save and exit (Ctrl+X, Y, Enter)
```

#### 7. Start the Backend
```bash
# Make deployment script executable
chmod +x deploy.sh

# Run the deployment script
./deploy.sh

# Or start manually:
npm start
```

#### 8. Test on DreamHost VPS
```bash
# Test health endpoint
curl http://localhost:3001/health

# Test from external (replace with your domain)
curl http://vps64698.dreamhostps.com:3001/health
```

### DreamHost VPS Firewall Configuration

DreamHost VPS typically has UFW (Uncomplicated Firewall):

```bash
# Check firewall status
sudo ufw status

# If inactive, enable it
sudo ufw enable

# Allow SSH (important!)
sudo ufw allow ssh

# Allow port 3001 for your backend
sudo ufw allow 3001

# Allow HTTP and HTTPS
sudo ufw allow 80
sudo ufw allow 443

# Check status
sudo ufw status verbose
```

### Running Backend as a Service on DreamHost

#### Option 1: Using PM2 (Recommended)
```bash
# Install PM2 globally
sudo npm install -g pm2

# Start your backend with PM2
pm2 start server.js --name "scriptor-umbra"

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
# Follow the instructions it provides

# Check status
pm2 status
pm2 logs scriptor-umbra
```

#### Option 2: Using systemd service
```bash
# Create a systemd service file
sudo nano /etc/systemd/system/scriptor-umbra.service

# Add this content:
[Unit]
Description=Scriptor Umbra AI Backend
After=network.target

[Service]
Type=simple
User=username
WorkingDirectory=/home/username/scriptor-umbra-backend
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target

# Save and exit

# Reload systemd
sudo systemctl daemon-reload

# Enable and start the service
sudo systemctl enable scriptor-umbra
sudo systemctl start scriptor-umbra

# Check status
sudo systemctl status scriptor-umbra
```

### DreamHost Apache Integration

If you want to serve your frontend from the same domain:

```bash
# Navigate to your domain directory
cd ~/yourdomain.com/

# Upload your frontend files here
# (from DRAG_TO_DOMAIN folder)

# Create .htaccess for API proxy
nano .htaccess

# Add this content:
RewriteEngine On

# Proxy API requests to Node.js backend
RewriteRule ^api/(.*)$ http://localhost:3001/api/$1 [P,L]

# Handle React Router
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]

# Save and exit
```

### Monitoring Your DreamHost Deployment

```bash
# Check if backend is running
ps aux | grep node

# Check port usage
sudo netstat -tlnp | grep 3001

# Check logs (if using PM2)
pm2 logs scriptor-umbra

# Check system resources
htop
# or
top

# Check disk usage
df -h
du -sh ~/scriptor-umbra-backend/
```

### DreamHost VPS Specific Troubleshooting

#### If Node.js installation fails:
```bash
# Try alternative installation method
sudo apt remove nodejs npm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18
```

#### If port 3001 is blocked:
```bash
# Check what's using the port
sudo lsof -i :3001

# Try a different port
nano .env
# Change PORT=3001 to PORT=3002 or another port
```

#### If npm install fails:
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules
rm -rf node_modules/

# Try with different registry
npm install --registry https://registry.npmjs.org/
```

### Your DreamHost URLs

Once deployed, your backend will be accessible at:
- **Health Check**: `http://vps64698.dreamhostps.com:3001/health`
- **API Endpoint**: `http://vps64698.dreamhostps.com:3001/api/chat/completion`

If you set up a domain, it would be:
- **Health Check**: `http://yourdomain.com:3001/health`
- **API Endpoint**: `http://yourdomain.com:3001/api/chat/completion`

### Next Steps for DreamHost

1. **Test the deployment** using the URLs above
2. **Configure your frontend** to use the DreamHost backend URL
3. **Set up SSL certificate** through DreamHost panel
4. **Monitor the service** using PM2 or systemd

Your Scriptor Umbra AI backend is now running on your DreamHost VPS!

