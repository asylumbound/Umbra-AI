# Scriptor Umbra AI - Intelligent Ghostwriting Assistant

A custom GPT-powered chat portal designed for professional ghostwriting assistance, featuring an elegant design inspired by modern AI interfaces and built with React and Node.js.

## 🎯 Overview

Scriptor Umbra AI is a sophisticated chat-based writing assistant that specializes in creating high-quality content including articles, books, copywriting, and other long-form content. The application features a clean, minimalist design with a dark theme and modern UI elements that provide an exceptional user experience.

### Key Features

- **Elegant UI Design**: Clean, minimalist interface matching modern AI chat platforms
- **Real-time Chat Interface**: Smooth conversation flow with typing indicators and animations
- **Modular API Integration**: Easy-to-configure backend supporting multiple AI providers
- **Responsive Design**: Optimized for both desktop and mobile devices
- **Error Handling**: Comprehensive error management with user-friendly feedback
- **Production Ready**: Built with security, rate limiting, and deployment best practices

## 🏗️ Architecture

### Frontend (React)
- **Framework**: React 18 with Vite
- **Styling**: Tailwind CSS with shadcn/ui components
- **Icons**: Lucide React icons
- **State Management**: React hooks (useState, useEffect)
- **Build Tool**: Vite for fast development and optimized production builds

### Backend (Node.js)
- **Framework**: Express.js
- **Security**: Helmet, CORS, Rate limiting
- **AI Integration**: OpenAI API with modular support for other providers
- **Environment**: dotenv for configuration management
- **Development**: Nodemon for hot reloading

## 📁 Project Structure

```
scriptor-umbra-ai/
├── scriptor-umbra-frontend/          # React frontend application
│   ├── src/
│   │   ├── components/ui/            # shadcn/ui components
│   │   ├── App.jsx                   # Main application component
│   │   ├── App.css                   # Application styles
│   │   └── main.jsx                  # Application entry point
│   ├── dist/                         # Production build output
│   ├── index.html                    # HTML template
│   ├── package.json                  # Frontend dependencies
│   └── vite.config.js               # Vite configuration
├── scriptor-umbra-backend/           # Node.js backend server
│   ├── routes/
│   │   └── chat.js                   # Chat API endpoints
│   ├── server.js                     # Express server setup
│   ├── package.json                  # Backend dependencies
│   ├── .env.example                  # Environment variables template
│   └── .env                          # Environment configuration
└── README.md                         # This documentation
```

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm/pnpm
- OpenAI API key (or other supported AI provider)

### Installation

1. **Clone or download the project files**

2. **Set up the backend:**
   ```bash
   cd scriptor-umbra-backend
   npm install
   cp .env.example .env
   # Edit .env file with your API keys
   npm run dev
   ```

3. **Set up the frontend:**
   ```bash
   cd scriptor-umbra-frontend
   pnpm install
   pnpm run dev
   ```

4. **Access the application:**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:3001

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the backend directory with the following variables:

```env
# Server Configuration
PORT=3001
NODE_ENV=development

# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here

# Alternative AI APIs (optional)
# ANTHROPIC_API_KEY=your_anthropic_api_key_here
# MISTRAL_API_KEY=your_mistral_api_key_here

# CORS Configuration
FRONTEND_URL=http://localhost:5173

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

### API Key Setup

1. **OpenAI API Key** (Primary):
   - Visit https://platform.openai.com/api-keys
   - Create a new API key
   - Add it to your `.env` file as `OPENAI_API_KEY`

2. **Alternative Providers** (Future Support):
   - Anthropic Claude: Add `ANTHROPIC_API_KEY`
   - Mistral AI: Add `MISTRAL_API_KEY`

## 🌐 Deployment

### Frontend Deployment Options

#### Option 1: Vercel (Recommended)
1. Build the frontend: `pnpm run build`
2. Deploy the `dist` folder to Vercel
3. Configure environment variables in Vercel dashboard

#### Option 2: Netlify
1. Build the frontend: `pnpm run build`
2. Deploy the `dist` folder to Netlify
3. Configure build settings: Build command: `pnpm run build`, Publish directory: `dist`

#### Option 3: Static Hosting
1. Build the frontend: `pnpm run build`
2. Upload the `dist` folder contents to your web server

### Backend Deployment Options

#### Option 1: Railway/Render
1. Connect your repository
2. Set environment variables
3. Deploy with automatic builds

#### Option 2: VPS/Cloud Server
1. Install Node.js on your server
2. Upload backend files
3. Install dependencies: `npm install`
4. Set up environment variables
5. Use PM2 for process management: `pm2 start server.js`

#### Option 3: Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3001
CMD ["npm", "start"]
```

### Production Configuration

For production deployment, update the following:

1. **Frontend API URL**: Update `API_BASE_URL` in `App.jsx` to your backend URL
2. **CORS Settings**: Update `FRONTEND_URL` in backend `.env` to your frontend URL
3. **Security**: Use HTTPS for both frontend and backend
4. **Environment**: Set `NODE_ENV=production` in backend

## 🔧 API Documentation

### Chat Endpoints

#### POST /api/chat/completion
Send a message to the AI and receive a response.

**Request Body:**
```json
{
  "message": "Your message here",
  "conversation": [
    {
      "type": "user",
      "content": "Previous user message"
    },
    {
      "type": "ai", 
      "content": "Previous AI response"
    }
  ]
}
```

**Response:**
```json
{
  "success": true,
  "response": "AI generated response",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "model": "gpt-3.5-turbo"
}
```

#### GET /api/chat/health
Check the health status of the chat service.

**Response:**
```json
{
  "status": "OK",
  "service": "Chat API",
  "openai_configured": true,
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

#### GET /api/chat/models
Get available AI models and their status.

**Response:**
```json
{
  "models": [
    {
      "id": "openai-gpt-3.5-turbo",
      "name": "GPT-3.5 Turbo",
      "provider": "OpenAI",
      "available": true
    }
  ],
  "default_model": "openai-gpt-3.5-turbo"
}
```

## 🎨 Design System

### Color Scheme
- **Primary**: Dark navy/black for navigation and primary elements
- **Secondary**: Light gray for secondary content
- **Background**: Clean white/light background
- **Accent**: Green for branding, purple/pink for interactive elements
- **Error**: Red for error states and alerts

### Typography
- **Font Family**: Clean, modern sans-serif
- **Headings**: Bold weights for hierarchy
- **Body Text**: Regular weight for readability
- **UI Text**: Medium weight for interface elements

### Components
- **Buttons**: Rounded corners with hover states
- **Input Fields**: Clean borders with focus states
- **Message Bubbles**: Rounded with distinct styling for user/AI
- **Navigation**: Clean horizontal layout with clear sections

## 🔒 Security Features

- **Rate Limiting**: Prevents API abuse with configurable limits
- **CORS Protection**: Configured for specific frontend origins
- **Input Validation**: Server-side validation for all API inputs
- **Error Handling**: Secure error messages without sensitive data exposure
- **Environment Variables**: Secure configuration management

## 🧪 Testing

### Frontend Testing
```bash
cd scriptor-umbra-frontend
pnpm run dev    # Development server
pnpm run build  # Production build
pnpm run preview # Preview production build
```

### Backend Testing
```bash
cd scriptor-umbra-backend
npm run dev     # Development server with hot reload
npm start       # Production server
```

### API Testing
Use tools like Postman or curl to test API endpoints:
```bash
curl -X POST http://localhost:3001/api/chat/completion \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, can you help me write?"}'
```

## 🐛 Troubleshooting

### Common Issues

1. **API Key Invalid Error**
   - Verify your OpenAI API key is correct
   - Check that the key has sufficient credits
   - Ensure the key is properly set in the `.env` file

2. **CORS Errors**
   - Verify `FRONTEND_URL` matches your frontend URL
   - Check that both frontend and backend are running
   - Ensure no trailing slashes in URLs

3. **Build Errors**
   - Clear node_modules and reinstall dependencies
   - Check Node.js version compatibility
   - Verify all environment variables are set

4. **Connection Refused**
   - Ensure backend server is running on correct port
   - Check firewall settings for local development
   - Verify API_BASE_URL in frontend matches backend

### Debug Mode
Enable debug logging by setting `NODE_ENV=development` in your backend `.env` file.

## 📝 License

This project is provided as-is for educational and commercial use. Please ensure compliance with OpenAI's usage policies when using their API.

## 🤝 Support

For issues and questions:
1. Check the troubleshooting section above
2. Verify your environment configuration
3. Test with the provided examples
4. Review the API documentation

## 🔄 Updates and Maintenance

### Adding New AI Providers
The backend is designed to support multiple AI providers. To add a new provider:

1. Install the provider's SDK
2. Add configuration to `.env.example`
3. Update the chat route in `routes/chat.js`
4. Add the provider to the models endpoint

### Customizing the UI
The frontend uses Tailwind CSS and shadcn/ui components for easy customization:

1. Modify colors in `App.css`
2. Update component styling in `App.jsx`
3. Add new shadcn/ui components as needed
4. Customize the design system variables

---

**Built with ❤️ for professional content creators and writers**

