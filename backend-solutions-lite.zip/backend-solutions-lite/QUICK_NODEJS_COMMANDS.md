# 🚀 Quick Node.js Setup Commands - DreamHost VPS

## ⚡ **Copy-Paste Command Sequence**

Run these commands one by one on your VPS:

### **1. Install Node.js**
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
```

### **2. Reload Shell**
```bash
source ~/.bashrc
```

### **3. Install Latest Node.js**
```bash
nvm install --lts && nvm use --lts
```

### **4. Verify Installation**
```bash
node --version && npm --version
```

### **5. Install Backend Dependencies**
```bash
npm install --production
```

### **6. Create Environment File**
```bash
cp .env.production .env
```

### **7. Test Server**
```bash
node server.js
```

## 🔧 **If NVM Doesn't Work, Try This:**

```bash
sudo apt update && sudo apt install -y nodejs npm
```

## ✅ **Success Indicators**
- `node --version` shows v18+ or v20+
- `npm --version` shows 8+ or 9+
- `npm install` completes without errors
- `node server.js` starts without errors

## 🚨 **Common Issues**

**"curl: command not found"**
```bash
sudo apt install curl
```

**"Permission denied"**
```bash
sudo chown -R $USER:$USER .
```

**"Port 3001 in use"**
```bash
sudo lsof -i :3001
sudo kill -9 [PID]
```

Run these commands and your backend should be ready!

