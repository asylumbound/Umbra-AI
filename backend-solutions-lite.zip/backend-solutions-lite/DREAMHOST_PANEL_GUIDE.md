# 🔧 DreamHost Panel SSH Fix Guide

## 🎯 What to Check in Your DreamHost Panel

### Step 1: Log into DreamHost Panel
- **URL**: https://panel.dreamhost.com
- **Username**: meka@allenhenson.com
- **Password**: &&77DEfend

### Step 2: Navigate to VPS Settings
1. **Go to**: VPS → Manage VPS
2. **Find**: vps64698.dreamhostps.com
3. **Look for**: SSH Access or Shell Access settings

### Step 3: Check SSH Status
Look for these settings:
- ✅ **SSH Enabled**: Should be ON/Enabled
- ✅ **SSH Port**: Should be 22 (default)
- ✅ **SSH Users**: Check if users are created
- ✅ **Firewall**: Check if SSH is allowed

### Step 4: SSH User Management
1. **Go to**: Users → Manage Users
2. **Check**: Shell access for your user
3. **Enable**: Shell/SSH access if disabled
4. **Reset**: Password if needed

### Step 5: VPS Status
1. **Check**: VPS is running (not stopped/suspended)
2. **Verify**: No maintenance mode
3. **Confirm**: VPS is fully provisioned

## 🔧 Common Fixes in DreamHost Panel

### Fix 1: Enable SSH Access
- Navigate to **Users** section
- Find your user account
- Enable **Shell Access**
- Set a strong password

### Fix 2: Check VPS Status
- Go to **VPS** section
- Ensure VPS is **Running**
- If stopped, click **Start**

### Fix 3: Firewall Settings
- Look for **Security** or **Firewall** settings
- Ensure SSH (port 22) is allowed
- Add rule if missing

### Fix 4: Create New SSH User
If no SSH users exist:
1. **Go to**: Users → Add User
2. **Select**: Shell User
3. **Set**: Username and password
4. **Assign**: To your VPS

## 🚀 Alternative Deployment Methods

### Option 1: DreamHost Web Terminal
1. **In Panel**: Look for "Web Terminal" or "Console"
2. **Access**: Browser-based terminal
3. **Deploy**: Use same commands as SSH

### Option 2: SFTP + Manual Setup
1. **Upload files**: Via SFTP (you have credentials)
2. **Use Web Terminal**: For command execution
3. **Deploy**: Step by step through web interface

### Option 3: Cloud Deployment (Recommended)
Skip VPS entirely and use cloud services:

**Railway Deployment:**
1. Go to https://railway.app
2. Upload your `BACKEND_STANDALONE` folder
3. Railway handles everything automatically
4. Get instant URL for your backend

**Render Deployment:**
1. Go to https://render.com
2. Create new Web Service
3. Upload backend folder
4. Auto-deploys with your credentials

## 📋 What to Look For

### SSH Connection Working:
```bash
ssh username@vps64698.dreamhostps.com
# Should connect without "connection refused"
```

### SSH User Exists:
- Username shows in DreamHost Users section
- Shell access is enabled
- Password is set and working

### VPS is Running:
- Status shows "Running" not "Stopped"
- No maintenance notifications
- Resources are allocated

## 🆘 If SSH Still Fails

### Contact DreamHost Support:
- **Live Chat**: Available in panel
- **Phone**: 1-855-464-7342
- **Email**: Through panel support system

### Use Alternative Methods:
1. **Web Terminal**: Browser-based access
2. **SFTP Deployment**: File upload + web commands
3. **Cloud Services**: Skip VPS entirely

## ✅ Success Indicators

You'll know SSH is fixed when:
```bash
ssh username@vps64698.dreamhostps.com
Welcome to Ubuntu 20.04.x LTS
username@vps64698:~$
```

## 🎯 Next Steps After SSH Works

1. **Install Node.js**:
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

2. **Upload Backend**:
```bash
mkdir -p ~/scriptor-umbra-backend
cd ~/scriptor-umbra-backend
# Upload files via SCP or SFTP
```

3. **Deploy**:
```bash
npm install
chmod +x deploy.sh
./deploy.sh
```

---

**Take your time in the panel - the most common issue is SSH access not being enabled for the user account.**

