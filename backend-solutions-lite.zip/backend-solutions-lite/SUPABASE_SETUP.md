# Supabase Setup Guide for Scriptor Umbra AI

## 🔑 Your Supabase Configuration

Based on your JWT token, here are your Supabase project details:

```javascript
// Decoded JWT Information
{
  "iss": "supabase",
  "ref": "lqyopzfoyllmgfbnjczt",  // Your project reference
  "role": "anon",                 // Anonymous role
  "iat": 1750635086,             // Issued at
  "exp": 2066211086              // Expires at
}
```

**Your Supabase Project URL**: `https://lqyopzfoyllmgfbnjczt.supabase.co`
**Your Anon Key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k`

## 🚀 Quick Setup Steps

### 1. Access Your Supabase Dashboard
1. Go to https://supabase.com/dashboard
2. Navigate to your project: `lqyopzfoyllmgfbnjczt`
3. Go to **SQL Editor**

### 2. Run the Database Schema
1. Copy the contents of `supabase_schema.sql`
2. Paste into the SQL Editor
3. Click **Run** to create all tables and policies

### 3. Configure Authentication
1. Go to **Authentication** → **Settings**
2. Enable **Email** provider
3. Configure **Site URL**: Your domain (e.g., `https://scriptorumbra.ai`)
4. Add **Redirect URLs**: 
   - `https://scriptorumbra.ai/auth/callback`
   - `http://localhost:3000/auth/callback` (for development)

### 4. Get Your Service Role Key
1. Go to **Settings** → **API**
2. Copy the **service_role** key (needed for backend)
3. Keep this secret and secure!

## 🔧 Environment Variables

Add these to your backend `.env` file:

```env
# Supabase Configuration
SUPABASE_URL=https://lqyopzfoyllmgfbnjczt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxeW9wemZveWxsbWdmYm5qY3p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA2MzUwODYsImV4cCI6MjA2NjIxMTA4Nn0.nlD1DJZO2sTuoNWr4WXLr3GOM3hqq0EgpA2c-59aD6k
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here

# Existing OpenAI Configuration
OPENAI_API_KEY=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
ASSISTANT_ID=asst_SIM27MLhW3jL4xRG6SyNzFzc
```

## 📊 Database Schema Overview

### Tables Created:
1. **user_profiles** - Extended user information
2. **conversations** - Chat conversations with OpenAI threads
3. **messages** - Individual messages in conversations
4. **api_usage** - Track API usage and costs

### Features:
- ✅ Row Level Security (RLS) enabled
- ✅ Automatic profile creation on signup
- ✅ User-specific data isolation
- ✅ Conversation and message management
- ✅ API usage tracking
- ✅ Subscription tier support

## 🔐 Security Features

- **Row Level Security**: Users can only access their own data
- **JWT Authentication**: Secure token-based authentication
- **API Rate Limiting**: Built-in usage tracking
- **Data Isolation**: Complete separation between users

## 🧪 Testing the Setup

After running the schema, test in the SQL Editor:

```sql
-- Check if tables were created
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('user_profiles', 'conversations', 'messages', 'api_usage');

-- Check RLS policies
SELECT schemaname, tablename, policyname 
FROM pg_policies 
WHERE schemaname = 'public';
```

## 🎯 Next Steps

1. ✅ Database schema created
2. ⏳ Update backend with Supabase integration
3. ⏳ Update frontend with authentication UI
4. ⏳ Test complete flow
5. ⏳ Deploy updated application

Your Supabase project is now ready for integration with Scriptor Umbra AI!

