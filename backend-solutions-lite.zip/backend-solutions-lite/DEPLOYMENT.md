# Scriptor Umbra AI - Deployment Guide

This guide provides step-by-step instructions for deploying Scriptor Umbra AI to various hosting platforms.

## 🎯 Deployment Overview

Scriptor Umbra AI consists of two main components:
- **Frontend**: React application (static files)
- **Backend**: Node.js Express server (API)

These can be deployed separately or together depending on your hosting preference.

## 🌐 Frontend Deployment

### Vercel (Recommended for Frontend)

Vercel provides excellent support for React applications with automatic deployments.

#### Step 1: Prepare Your Code
```bash
cd scriptor-umbra-frontend
pnpm run build
```

#### Step 2: Deploy to Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. Login: `vercel login`
3. Deploy: `vercel --prod`
4. Follow the prompts to configure your project

#### Step 3: Configure Environment Variables
In your Vercel dashboard:
1. Go to your project settings
2. Navigate to "Environment Variables"
3. Add any frontend-specific variables if needed

#### Alternative: GitHub Integration
1. Push your code to GitHub
2. Connect your repository to Vercel
3. Configure build settings:
   - Build Command: `pnpm run build`
   - Output Directory: `dist`
   - Install Command: `pnpm install`

### Netlify

#### Step 1: Build Your Application
```bash
cd scriptor-umbra-frontend
pnpm run build
```

#### Step 2: Deploy via Drag & Drop
1. Visit https://app.netlify.com/drop
2. Drag the `dist` folder to the deployment area
3. Your site will be deployed instantly

#### Step 3: Configure Custom Domain (Optional)
1. Go to your site settings in Netlify
2. Navigate to "Domain management"
3. Add your custom domain

#### Alternative: Git Integration
1. Connect your repository to Netlify
2. Configure build settings:
   - Build command: `pnpm run build`
   - Publish directory: `dist`
   - Node version: 18

### Static Hosting (cPanel, Apache, Nginx)

#### Step 1: Build for Production
```bash
cd scriptor-umbra-frontend
pnpm run build
```

#### Step 2: Upload Files
1. Upload all contents of the `dist` folder to your web server
2. Ensure the files are in the public HTML directory
3. Configure your web server to serve the `index.html` for all routes

#### Step 3: Configure Web Server
For Apache, create a `.htaccess` file:
```apache
RewriteEngine On
RewriteBase /
RewriteRule ^index\.html$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]
```

For Nginx:
```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

## 🖥️ Backend Deployment

### Railway (Recommended for Backend)

Railway provides excellent Node.js hosting with automatic deployments.

#### Step 1: Prepare Your Backend
1. Ensure your `package.json` has the correct start script
2. Create a `railway.json` file (optional):
```json
{
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "npm start",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}
```

#### Step 2: Deploy to Railway
1. Install Railway CLI: `npm install -g @railway/cli`
2. Login: `railway login`
3. Initialize: `railway init`
4. Deploy: `railway up`

#### Step 3: Configure Environment Variables
```bash
railway variables set OPENAI_API_KEY=your_key_here
railway variables set NODE_ENV=production
railway variables set FRONTEND_URL=https://your-frontend-domain.com
```

### Render

#### Step 1: Connect Repository
1. Go to https://render.com
2. Connect your GitHub repository
3. Select "Web Service"

#### Step 2: Configure Service
- **Name**: scriptor-umbra-backend
- **Environment**: Node
- **Build Command**: `npm install`
- **Start Command**: `npm start`
- **Instance Type**: Free or Starter

#### Step 3: Set Environment Variables
Add the following in Render dashboard:
```
OPENAI_API_KEY=your_openai_key
NODE_ENV=production
FRONTEND_URL=https://your-frontend-url.com
PORT=10000
```

### DigitalOcean App Platform

#### Step 1: Create App
1. Go to DigitalOcean App Platform
2. Create a new app from GitHub repository

#### Step 2: Configure Component
```yaml
name: scriptor-umbra-backend
source_dir: /scriptor-umbra-backend
github:
  repo: your-username/your-repo
  branch: main
run_command: npm start
environment_slug: node-js
instance_count: 1
instance_size_slug: basic-xxs
```

#### Step 3: Environment Variables
Set in the App Platform dashboard:
- `OPENAI_API_KEY`
- `NODE_ENV=production`
- `FRONTEND_URL`

### VPS/Cloud Server (Ubuntu)

#### Step 1: Server Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2
```

#### Step 2: Deploy Application
```bash
# Clone or upload your code
git clone your-repository.git
cd scriptor-umbra-backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env
nano .env  # Edit with your configuration
```

#### Step 3: Configure PM2
Create `ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'scriptor-umbra-backend',
    script: 'server.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    }
  }]
}
```

Start with PM2:
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

#### Step 4: Configure Nginx (Optional)
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🐳 Docker Deployment

### Frontend Dockerfile
```dockerfile
# Build stage
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

# Production stage
FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Backend Dockerfile
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --only=production
COPY . .
EXPOSE 3001
USER node
CMD ["npm", "start"]
```

### Docker Compose
```yaml
version: '3.8'
services:
  frontend:
    build: ./scriptor-umbra-frontend
    ports:
      - "80:80"
    depends_on:
      - backend

  backend:
    build: ./scriptor-umbra-backend
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=production
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - FRONTEND_URL=http://localhost
    env_file:
      - ./scriptor-umbra-backend/.env
```

## 🔧 Production Configuration

### Frontend Configuration
Update the API URL in your frontend before building:

```javascript
// In src/App.jsx
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://your-backend-domain.com/api'
  : 'http://localhost:3001/api'
```

### Backend Configuration
Ensure your production `.env` file includes:

```env
NODE_ENV=production
PORT=3001
OPENAI_API_KEY=your_production_key
FRONTEND_URL=https://your-frontend-domain.com
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

### Security Considerations

1. **HTTPS**: Always use HTTPS in production
2. **Environment Variables**: Never commit `.env` files
3. **API Keys**: Use production API keys with appropriate limits
4. **CORS**: Configure CORS for your specific domain
5. **Rate Limiting**: Adjust rate limits based on your needs

## 🔍 Monitoring and Maintenance

### Health Checks
Set up monitoring for these endpoints:
- Frontend: `https://your-domain.com`
- Backend: `https://your-api-domain.com/health`
- Chat API: `https://your-api-domain.com/api/chat/health`

### Logging
For production deployments, consider:
- Application logging with Winston
- Error tracking with Sentry
- Performance monitoring with New Relic

### Backup Strategy
- Regular database backups (if using a database)
- Environment variable backups
- Code repository backups

## 🚀 Scaling Considerations

### Frontend Scaling
- Use CDN for static assets
- Enable gzip compression
- Implement caching headers

### Backend Scaling
- Use load balancers for multiple instances
- Implement database connection pooling
- Consider Redis for session management

### Cost Optimization
- Monitor API usage and costs
- Implement request caching
- Use appropriate instance sizes

## 📋 Deployment Checklist

### Pre-Deployment
- [ ] Test application locally
- [ ] Update API URLs for production
- [ ] Configure environment variables
- [ ] Test with production API keys
- [ ] Review security settings

### Deployment
- [ ] Deploy backend first
- [ ] Test backend endpoints
- [ ] Deploy frontend
- [ ] Test full application flow
- [ ] Configure custom domains

### Post-Deployment
- [ ] Set up monitoring
- [ ] Configure SSL certificates
- [ ] Test from different devices
- [ ] Monitor error logs
- [ ] Set up backup procedures

---

This deployment guide covers the most common hosting scenarios. Choose the option that best fits your technical requirements and budget.

