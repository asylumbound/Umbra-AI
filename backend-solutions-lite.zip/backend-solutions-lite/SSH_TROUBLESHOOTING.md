# 🔧 SSH Connection Troubleshooting

## 🚨 Issue Identified

I can see from your screenshot that you're trying to connect to:
```bash
ssh scriptorumbra@scriptorumbra.ai
```

**This is the wrong server!** You need to connect to your **DreamHost VPS** instead.

## ✅ Correct Connection Details

### Your DreamHost VPS Connection:
```bash
ssh username@vps64698.dreamhostps.com
```

**Replace `username` with your actual DreamHost username** (likely `allenhenson` or similar)

## 🔍 Finding Your DreamHost SSH Credentials

### Method 1: Check DreamHost Panel
1. Log into your DreamHost panel
2. Go to **VPS** section
3. Look for **SSH Access** or **Shell Access**
4. Your username will be listed there

### Method 2: Common DreamHost Usernames
Try these common patterns:
```bash
ssh allenhenson@vps64698.dreamhostps.com
ssh meka@vps64698.dreamhostps.com
ssh admin@vps64698.dreamhostps.com
```

### Method 3: Use Your Domain Username
If you have a domain hosted on DreamHost:
```bash
ssh yourdomain@vps64698.dreamhostps.com
```

## 🔐 SSH Connection Commands

### Try These Connection Methods:

**Option 1: Standard SSH**
```bash
ssh allenhenson@vps64698.dreamhostps.com
```

**Option 2: Specify Port (if needed)**
```bash
ssh -p 22 allenhenson@vps64698.dreamhostps.com
```

**Option 3: Verbose Mode (for debugging)**
```bash
ssh -v allenhenson@vps64698.dreamhostps.com
```

**Option 4: Force Password Authentication**
```bash
ssh -o PreferredAuthentications=password allenhenson@vps64698.dreamhostps.com
```

## 🛠️ Troubleshooting Steps

### Step 1: Test Connection
```bash
# Test if the server is reachable
ping vps64698.dreamhostps.com

# Test if SSH port is open
telnet vps64698.dreamhostps.com 22
# Press Ctrl+C to exit if it connects
```

### Step 2: Check SSH Configuration
```bash
# Check your SSH config
cat ~/.ssh/config

# If you have conflicting entries, you might need to specify:
ssh -F /dev/null username@vps64698.dreamhostps.com
```

### Step 3: Clear Known Hosts (if needed)
```bash
# If you get host key errors
ssh-keygen -R vps64698.dreamhostps.com
ssh-keygen -R scriptorumbra.ai
```

## 🔑 Password Issues

From your screenshot, I see password authentication is failing. Here's what to try:

### Reset Your Password
1. **Log into DreamHost Panel**
2. **Go to Users section**
3. **Find your VPS user**
4. **Reset the password**
5. **Try SSH again with new password**

### Alternative: Use SSH Key
```bash
# Generate SSH key if you don't have one
ssh-keygen -t rsa -b 4096 -C "your-email@example.com"

# Copy public key to clipboard (Mac)
pbcopy < ~/.ssh/id_rsa.pub

# Then add it to DreamHost panel under SSH Keys
```

## 🌐 Alternative: Use DreamHost Web Terminal

If SSH continues to fail, DreamHost provides a web-based terminal:

1. **Log into DreamHost Panel**
2. **Go to VPS section**
3. **Look for "Web Terminal" or "Console Access"**
4. **Use the browser-based terminal**

## 📋 Once Connected Successfully

When you successfully connect to your DreamHost VPS, you'll see something like:
```bash
Welcome to Ubuntu 20.04.x LTS (GNU/Linux ...)
username@vps64698:~$
```

Then proceed with the backend deployment:

```bash
# Check you're in the right place
pwd
# Should show: /home/username

# Check if Node.js is installed
node --version

# If not installed:
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Create backend directory
mkdir -p ~/scriptor-umbra-backend
cd ~/scriptor-umbra-backend
```

## 🚨 Common SSH Errors and Solutions

### "Connection timed out"
- **Cause**: Wrong hostname or firewall blocking
- **Solution**: Use correct hostname `vps64698.dreamhostps.com`

### "Permission denied (publickey)"
- **Cause**: SSH key authentication failing
- **Solution**: Use password authentication or add SSH key

### "Host key verification failed"
- **Cause**: Host key changed or conflicts
- **Solution**: Remove old key with `ssh-keygen -R hostname`

### "Connection refused"
- **Cause**: SSH service not running or wrong port
- **Solution**: Contact DreamHost support

## 🔄 Next Steps

1. **Connect to correct server**: `ssh username@vps64698.dreamhostps.com`
2. **Install Node.js** (if needed)
3. **Upload your backend files**
4. **Deploy using the provided scripts**

## 📞 DreamHost Support

If you continue having issues:
- **DreamHost Support**: Available 24/7
- **Live Chat**: Through DreamHost panel
- **Email**: support@dreamhost.com

## ✅ Success Indicators

You'll know you're connected successfully when you see:
```bash
username@vps64698:~$
```

Then you can proceed with the backend deployment using the commands from the deployment guide.

---

**The key issue**: You were trying to connect to `scriptorumbra.ai` instead of your DreamHost VPS at `vps64698.dreamhostps.com`. Use the correct hostname and you should be able to connect!

